# 🕌 Cerdas Cermat Santri — Konsol Lomba Offline Multi-Device

Aplikasi konsol lomba **Cerdas Cermat / Musabaqah** untuk acara offline (proyektor, tanpa HP peserta).
Satu laptop panitia menjadi server lokal; laptop admin juri dan laptop proyektor tersinkron **real-time lewat LAN/WiFi — tanpa internet**.

## ✨ Fitur Utama
- ⏱️ **Timer countdown raksasa** di layar proyektor + **dibacakan bersuara** (TTS Indonesia, 100% offline).
- ✉️ **Amplop virtual** (A/B/C/D) untuk sesi Soal Wajib.
- 🔄 **Soal lemparan wajib diterima** — rotasi otomatis ke regu berikutnya + penalti configurable.
- ⚡ **Bel rebutan** dengan pencatatan timestamp milidetik di server (anti sengketa juri).
- 🎡 Roda putar giliran, soal **pilihan ganda**, **clue bertingkat**, **tebak gambar**, dan **soal audio/qiroah** (folder `media/`).
- 🏆 Fase **Pengumuman**: podium juara 1-2-3 + konfeti langsung dari aplikasi (tanpa PDF).
- 📦 Bank soal: bawaan 20 butir, impor **XLSX/CSV/JSON**, editor visual, tersimpan permanen di server.
- 💾 Snapshot otomatis (`data/game-snapshot.json`) — skor & bank soal pulih bila server/laptop mati mendadak.
- 📱 Bonus: rute `/bel/:roomId` sebagai bel darurat via HP/tablet (tetap lewat LAN).

## 🚀 Instalasi & Menjalankan

```bash
npm install
npm run build      # build frontend sekali (wajib sebelum hari-H)
npm start          # jalankan server produksi di port 4600
```

Mode pengembangan (hot-reload):

```bash
npm run dev        # tsx server.ts + vite dev server
```

Saat server menyala, alamat IP LAN otomatis ditampilkan, contoh:

```
Laptop Admin Juri : http://192.168.1.50:4600/admin/lomba
Layar Proyektor   : http://192.168.1.50:4600/stage/lomba
```

Buka kedua URL itu di dua laptop yang terhubung ke WiFi/LAN pondok yang sama. Selesai — semua aksi admin langsung tersinkron ke layar proyektor.

## 🎮 Keyboard Shortcut (Panel Admin)
| Tombol | Aksi |
|---|---|
| `Spasi` | Mulai / jeda timer |
| `J` | Tampilkan jawaban & pembahasan |
| `N` | Selesaikan soal (lanjut amplop/giliran) |
| `R` | Reset timer |
| `C` | Buka clue berikutnya (tipe clue) |
| `1–9` | Beri poin cepat ke regu ke-n |

## 🗂 Struktur Folder
```
server.ts               # Express + Socket.IO + penyimpanan snapshot
index.html / src/       # Frontend React + Vite + Tailwind
src/pages/Admin.tsx     # Panel kendali juri
src/pages/Stage.tsx     # Layar proyektor penonton
src/components/         # BigTimer, EnvelopeSelector, PodiumView, SpinWheel, dll.
src/data/               # Bank soal bawaan
media/                  # Taruh file gambar/audio soal bonus di sini sebelum hari-H
```

## 🧰 Checklist Hari-H
1. `npm install && npm run build` sehari sebelumnya.
2. Isi folder `media/` dengan gambar/audio soal bonus.
3. Impor bank soal final (tab *Bank Soal* → Import XLSX/JSON), cek tampilannya di stage.
4. Klik sekali di layar proyektor untuk mengaktifkan suara (kebijakan autoplay browser).
5. Matikan WiFi internet tidak masalah — yang penting kedua laptop satu jaringan LAN.
6. Backup `data/game-snapshot.json` setelah lomba bila perlu arsip nilai.

## ❓ Troubleshooting
- **Proyektor tidak tersinkron** → pastikan kedua laptop satu jaringan WiFi/AP yang sama & firewall laptop server mengizinkan port 4600.
- **Tidak ada suara** → klik dulu halaman stage, cek volume, atau ganti bahasa TTS di tab Aturan.
- **Port bentrok** → ubah `PORT` (env) atau di `server.ts`.
