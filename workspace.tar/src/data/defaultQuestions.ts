import { Question } from '../types';

// Bank soal bawaan — 2 butir per tipe/amplop. Silakan sunting/ganti lewat
// panel Admin (tab "Bank Soal") atau impor XLSX/JSON sebelum hari-H.
export const defaultQuestions: Question[] = [
  // ================= SOAL WAJIB (Amplop A–D) =================
  {
    id: 'w1', type: 'wajib', packet: 'Amplop A', category: 'Al-Quran', points: 20,
    text: 'Surah Al-Fatihah disebut juga "Ummul Quran" yang berarti…',
    answer: 'Induk Al-Quran',
  },
  {
    id: 'w2', type: 'wajib', packet: 'Amplop A', category: 'Akidah', points: 20,
    text: 'Berapa jumlah rukun Islam?',
    answer: '5 (lima)',
  },
  {
    id: 'w3', type: 'wajib', packet: 'Amplop B', category: 'Hadits', points: 20,
    text: 'Kitab hadits yang disusun oleh Imam Bukhari dikenal dengan nama…',
    answer: 'Shahih Al-Bukhari',
  },
  {
    id: 'w4', type: 'wajib', packet: 'Amplop B', category: 'Fiqih', points: 20,
    text: 'Berapa jumlah rakaat shalat Subuh?',
    answer: '2 rakaat',
  },
  {
    id: 'w5', type: 'wajib', packet: 'Amplop C', category: 'Sirah', points: 20,
    text: 'Siapakah khalifah pertama dalam sejarah Islam?',
    answer: 'Abu Bakar Ash-Shiddiq RA',
  },
  {
    id: 'w6', type: 'wajib', packet: 'Amplop C', category: 'Bahasa Arab', points: 20,
    text: 'Bahasa Arab dari kata "buku" adalah…',
    answer: 'كِتَاب (Kitaab)',
  },
  {
    id: 'w7', type: 'wajib', packet: 'Amplop D', category: 'Al-Quran', points: 20,
    text: 'Ayat Kursi terdapat dalam surah apa dan ayat ke berapa?',
    answer: 'Surah Al-Baqarah ayat 255',
  },
  {
    id: 'w8', type: 'wajib', packet: 'Amplop D', category: 'Iptek Islami', points: 20,
    text: 'Ilmuwan muslim penemu aljabar yang namanya menjadi istilah "algorithm" adalah…',
    answer: 'Al-Khawarizmi',
  },

  // ================= SOAL LEMPAR =================
  {
    id: 'l1', type: 'lempar', category: 'Al-Quran', points: 20,
    text: 'Surah terpanjang dalam Al-Quran adalah…',
    answer: 'Al-Baqarah',
  },
  {
    id: 'l2', type: 'lempar', category: 'Sirah', points: 20,
    text: 'Perang pertama dalam Islam yang terjadi pada bulan Ramadhan adalah…',
    answer: 'Perang Badar',
  },

  // ================= SOAL REBUTAN =================
  {
    id: 'r1', type: 'rebutan', category: 'Hadits', points: 30,
    text: '"Innamal a\'malu…" lanjutkan potongan hadits tentang niat.',
    answer: '…bin Niyyat (sesungguhnya amal itu tergantung niatnya)',
  },
  {
    id: 'r2', type: 'rebutan', category: 'Bahasa Arab', points: 30,
    text: 'Apa arti kata "madrasah" dalam bahasa Arab?',
    answer: 'Sekolah / tempat belajar',
  },

  // ================= PILIHAN GANDA =================
  {
    id: 'pg1', type: 'pilihan_ganda', category: 'Fiqih', points: 20,
    text: 'Tayamum boleh dilakukan apabila…',
    options: ['A. Terlambat ke masjid', 'B. Tidak ada air atau tidak mampu memakai air', 'C. Sedang sakit gigi', 'D. Baju najis'],
    answer: 'B',
  },
  {
    id: 'pg2', type: 'pilihan_ganda', category: 'Al-Quran', points: 20,
    text: 'Jumlah juz dalam Al-Quran adalah…',
    options: ['A. 20', 'B. 25', 'C. 30', 'D. 40'],
    answer: 'C',
  },

  // ================= SOAL CLUE (bertingkat) =================
  {
    id: 'c1', type: 'clue', category: 'Sirah', points: 40,
    text: 'Tebak tokoh berikut dari petunjuk bertahap:',
    clues: [
      'Aku adalah paman Rasulullah ﷺ.',
      'Aku wafat dalam pembelaan beliau di Perang Uhud.',
      'Gelar julukanku adalah "Singa Allah".',
    ],
    answer: 'Hamzah bin Abdul Muthalib RA',
  },
  {
    id: 'c2', type: 'clue', category: 'Iptek Islami', points: 40,
    text: 'Tebak ilmuwan berikut dari petunjuk bertahap:',
    clues: [
      'Aku dijuluki Bapak Kedokteran Modern.',
      'Karyaku yang paling terkenal berjudul "Al-Qanun fi Ath-Thibb".',
      'Orang Eropa menyebut namaku Avicenna.',
    ],
    answer: 'Ibnu Sina',
  },

  // ================= AUDIO (dengar & tebak) =================
  {
    id: 'a1', type: 'audio', category: 'Al-Quran', points: 30,
    text: 'Dengarkan lantunan berikut, lalu sebutkan nama surahnya!',
    audioUrl: '', // isi path file mis. "qiroah-yusuf.mp3" (taruh di folder ./media/)
    answer: 'Surah Yusuf',
  },
  {
    id: 'a2', type: 'audio', category: 'Nasyid/Hadits', points: 30,
    text: 'Dengarkan audio berikut, tentukan judul nasyid / matan haditsnya!',
    audioUrl: '',
    answer: 'Talaul Badri Alaina',
  },

  // ================= TEBAK GAMBAR (bonus) =================
  {
    id: 'g1', type: 'gambar', category: 'Bonus Gambar', points: 25,
    text: 'Perhatikan gambar di layar. Sebutkan objek apa ini dalam sejarah Islam!',
    questionImage: '', // mis. "kabah.jpg" di folder ./media/
    answer: 'Ka\u2019bah di Masjidil Haram, Makkah',
  },
  {
    id: 'g2', type: 'gambar', category: 'Bonus Gambar', points: 25,
    text: 'Bangunan bersejarah apakah yang tampak pada gambar ini?',
    questionImage: '', // mis. "masjid-nabawi.jpg"
    answer: 'Masjid Nabawi, Madinah',
  },
];
