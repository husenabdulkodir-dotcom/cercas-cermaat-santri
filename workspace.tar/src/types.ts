// Definisi tipe data — selaras dengan server.ts
export interface Group {
  id: string;      // kode tombol (slug nama), dipakai utk keypad USB & bel HP cadangan
  name: string;
  score: number;
}

export type QuestionType =
  | 'wajib' | 'lempar' | 'rebutan'
  | 'pilihan_ganda' | 'clue' | 'audio' | 'gambar';

export interface Question {
  id: string;
  text: string;
  answer: string;
  type: QuestionType;
  category: string;
  points: number;
  packet?: string;        // 'Amplop A', dst.
  options?: string[];     // PG: ['A. ...','B. ...','C. ...','D. ...']
  clues?: string[];       // soal bertingkat (clue)
  audioUrl?: string;      // URL/relatif/base64 audio qiroah, nasyid, hadits
  questionImage?: string; // tebak gambar (URL/relatif/base64)
  answerImage?: string;   // gambar pembahasan
}

export type GamePhase =
  | 'Persiapan' | 'Soal Wajib' | 'Soal Lempar' | 'Soal Rebutan'
  | 'Soal Bonus' | 'Pengumuman';

export interface BuzzerEvent { groupId: string; at: number }
export interface LogEntry { at: number; actor: 'admin' | 'system'; message: string }

export interface GameSettings {
  wajibSec: number;
  lemparSec: number;
  rebutanSec: number;
  bonusSec: number;
  penaltyLempar: number;
  speakCountdown: boolean;
  ttsVoice: 'id' | 'ar' | 'off';
}

export interface GameState {
  roomId: string;
  groups: Group[];
  questions: Question[];
  activeQuestion: Question | null;
  gamePhase: GamePhase;

  timerDurationSec: number;
  timerEndsAt: number | null;
  isTimerRunning: boolean;
  timeLeftOverride: number | null;

  buzzerEnabled: boolean;
  buzzQueue: BuzzerEvent[];
  buzzedGroupId: string | null;

  revealAnswer: boolean;
  openedEnvelope: string | null;
  usedQuestionIds: string[];
  activeTurnGroupId: string | null;
  passedGroupIds: string[];
  activeClueIndex: number;
  spinWheelResult: string | null;
  groupBets: Record<string, number>;

  settings: GameSettings;
  log: LogEntry[];
  updatedAt: number;
}

export const PHASES: GamePhase[] = [
  'Persiapan', 'Soal Wajib', 'Soal Lempar', 'Soal Rebutan', 'Soal Bonus', 'Pengumuman',
];

export const TYPE_LABEL: Record<QuestionType, string> = {
  wajib: 'Wajib',
  lempar: 'Lempar',
  rebutan: 'Rebutan',
  pilihan_ganda: 'Pilihan Ganda',
  clue: 'Soal Clue',
  audio: 'Audio / Dengar',
  gambar: 'Tebak Gambar',
};
