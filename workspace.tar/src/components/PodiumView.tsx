import { Trophy } from 'lucide-react';
import { motion } from 'motion/react';
import { Group } from '../types';

/** Podium juara 1-2-3 langsung dari aplikasi (tanpa PDF). */
export default function PodiumView({ groups }: { groups: Group[] }) {
  const sorted = [...groups].sort((a, b) => b.score - a.score);
  const top3 = sorted.slice(0, 3);
  const heights = ['h-40 md:h-56', 'h-28 md:h-40', 'h-20 md:h-28'];
  const medals = ['🥇', '🥈', '🥉'];
  const colors = [
    'from-amber-400 to-yellow-600',
    'from-slate-300 to-slate-500',
    'from-orange-400 to-amber-700',
  ];
  const order = [1, 0, 2]; // tampilan tengah-tinggi: juara 2, 1, 3

  return (
    <div className="flex flex-col items-center justify-end h-full w-full pb-8 select-none">
      <Trophy size={64} className="text-amber-400 mb-4 animate-bounce" />
      <div className="flex items-end justify-center gap-3 md:gap-6">
        {order.map((slotIdx, pos) => {
          const g = top3[slotIdx];
          if (!g) return <div key={`empty-${pos}`} className="w-36 md:w-48" />;
          return (
            <motion.div
              key={g.id}
              initial={{ y: 80, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: pos * 0.25, type: 'spring', stiffness: 120 }}
              className="flex flex-col items-center"
            >
              <div className="text-4xl mb-1">{medals[slotIdx]}</div>
              <div className="text-center mb-2 max-w-40">
                <p className="font-black text-white text-lg leading-tight">{g.name}</p>
                <p className="font-mono text-amber-300 font-bold">{g.score} pt</p>
              </div>
              <div className={`w-36 md:w-48 ${heights[slotIdx]} rounded-t-2xl bg-gradient-to-b ${colors[slotIdx]} flex items-start justify-center pt-3 shadow-2xl`}>
                <span className="text-5xl md:text-7xl font-black text-black/40">{slotIdx + 1}</span>
              </div>
            </motion.div>
          );
        })}
      </div>
      {/* Peringkat lengkap di bawah podium */}
      <div className="mt-6 flex flex-wrap justify-center gap-2 max-w-5xl px-4">
        {sorted.slice(3).map((g, i) => (
          <span key={g.id} className="px-3 py-1 rounded-full bg-slate-800 border border-slate-700 text-sm text-slate-300">
            #{i + 4} {g.name} — <b className="text-emerald-300">{g.score}</b>
          </span>
        ))}
      </div>
    </div>
  );
}
