/** Gelombang animasi sederhana (CSS) saat audio soal diputar. */
export default function AudioVisualizer({ playing }: { playing: boolean }) {
  const bars = [0.9, 1.4, 0.7, 1.8, 1.1, 1.6, 0.8, 1.3, 1.9, 1.0];
  return (
    <div className="flex items-end gap-1 h-10" aria-hidden>
      {bars.map((h, i) => (
        <span
          key={i}
          className="w-1.5 rounded-full bg-gradient-to-t from-rose-500 to-amber-400"
          style={{
            height: `${h * 18}px`,
            animation: playing ? `av-bar 0.${4 + (i % 5)}s ease-in-out infinite alternate` : 'none',
            opacity: playing ? 1 : 0.35,
          }}
        />
      ))}
      <style>{`@keyframes av-bar { from { transform: scaleY(0.3);} to { transform: scaleY(1);} }`}</style>
    </div>
  );
}
