import { useEffect } from 'react';
import confetti from 'canvas-confetti';

/** Konfeti selebrasi pemenang + fanfare singkat. */
export default function CelebrationEffects() {
  useEffect(() => {
    const end = Date.now() + 4000;
    const colors = ['#34d399', '#fbbf24', '#f472b6', '#60a5fa'];
    (function frame() {
      confetti({ particleCount: 4, angle: 60, spread: 60, origin: { x: 0 }, colors });
      confetti({ particleCount: 4, angle: 120, spread: 60, origin: { x: 1 }, colors });
      if (Date.now() < end) requestAnimationFrame(frame);
    })();
    confetti({ particleCount: 160, spread: 100, origin: { y: 0.6 }, colors });
  }, []);
  return null;
}
