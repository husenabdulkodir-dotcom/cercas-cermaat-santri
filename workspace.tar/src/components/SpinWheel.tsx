import { useEffect, useMemo, useRef, useState } from 'react';
import { motion } from 'motion/react';

interface Props {
  segments: string[];               // mis. nama regu atau kategori
  onResult?: (label: string) => void;
  disabled?: boolean;
}

/** Roda putar acak utk sesi bonus / penentuan giliran. */
export default function SpinWheel({ segments, onResult, disabled }: Props) {
  const [angle, setAngle] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const resultRef = useRef<string | null>(null);
  const colors = ['#34d399', '#fbbf24', '#f472b6', '#60a5fa', '#f87171', '#a78bfa', '#4ade80', '#fb923c'];

  const size = 320;
  const r = size / 2;

  const conic = useMemo(() => {
    if (!segments.length) return '#1e293b';
    const step = 360 / segments.length;
    return `conic-gradient(${segments
      .map((_, i) => `${colors[i % colors.length]} ${i * step}deg ${(i + 1) * step}deg`)
      .join(', ')})`;
  }, [segments]);

  const spin = () => {
    if (disabled || spinning || !segments.length) return;
    setSpinning(true);
    const extra = 5 * 360 + Math.floor(Math.random() * 360);
    const next = angle + extra;
    setAngle(next);
    const idx = Math.floor(((360 - (next % 360)) % 360) / (360 / segments.length)) % segments.length;
    resultRef.current = segments[idx];
    setTimeout(() => {
      setSpinning(false);
      if (resultRef.current) onResult?.(resultRef.current);
    }, 4200);
  };

  return (
    <div className="flex flex-col items-center gap-4 select-none">
      <div className="relative" style={{ width: size, height: size }}>
        {/* jarum penunjuk atas */}
        <div className="absolute left-1/2 -top-1 -translate-x-1/2 z-10 w-0 h-0
          border-l-[14px] border-r-[14px] border-t-[24px] border-l-transparent border-r-transparent border-t-red-500 drop-shadow-lg" />
        <motion.div
          animate={{ rotate: angle }}
          transition={{ duration: 4, ease: [0.12, 0.75, 0.1, 1] }}
          className="w-full h-full rounded-full border-8 border-slate-700 shadow-2xl"
          style={{ background: conic }}
        />
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          {segments.map((s, i) => {
            const step = 360 / segments.length;
            const a = ((i * step + step / 2) * Math.PI) / 180;
            return (
              <span
                key={s + i}
                className="absolute text-[11px] font-black text-slate-900 whitespace-nowrap"
                style={{ transform: `translate(${Math.cos(a) * r * 0.62}px, ${Math.sin(a) * r * 0.62}px) rotate(${i * step + step / 2}deg)` }}
              >
                {s.slice(0, 12)}
              </span>
            );
          })}
        </div>
      </div>
      <button
        onClick={spin}
        disabled={disabled || spinning || !segments.length}
        className="px-8 py-3 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 text-slate-950 font-black text-lg shadow-xl hover:scale-105 active:scale-95 transition disabled:opacity-40 disabled:hover:scale-100 cursor-pointer"
      >
        {spinning ? 'Memutar…' : 'PUTAR RODA'}
      </button>
    </div>
  );
}
