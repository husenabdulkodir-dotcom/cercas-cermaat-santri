import { useEffect, useMemo, useState } from 'react';
import { cn } from '../lib/utils';

interface BigTimerProps {
  durationSec: number;
  endsAt: number | null;      // epoch ms; null = tidak berjalan
  isRunning: boolean;
  frozenLeft: number | null;  // sisa detik saat pause/habis (dari server)
  className?: string;
}

/** Countdown raksasa utk layar proyektor — sinkron via deadline server. */
export default function BigTimer({ durationSec, endsAt, isRunning, frozenLeft, className }: BigTimerProps) {
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    if (!isRunning) return;
    const id = setInterval(() => setNow(Date.now()), 100);
    return () => clearInterval(id);
  }, [isRunning]);

  const leftSec = useMemo(() => {
    if (isRunning && endsAt) return Math.max(0, Math.ceil((endsAt - now) / 1000));
    if (frozenLeft != null) return frozenLeft;
    return durationSec;
  }, [isRunning, endsAt, now, frozenLeft, durationSec]);

  const pct = durationSec > 0 ? Math.min(1, leftSec / durationSec) : 0;
  const danger = leftSec <= 5 && isRunning;
  const warn = leftSec <= 10 && !danger;

  return (
    <div className={cn('flex flex-col items-center select-none', className)}>
      <div
        className={cn(
          'timer-giant font-black leading-none transition-colors',
          danger ? 'text-red-500 animate-pulse' : warn ? 'text-amber-400' : 'text-emerald-300',
        )}
        style={{ fontSize: 'clamp(4rem, 16vw, 12rem)' }}
      >
        {String(leftSec).padStart(2, '0')}
        <span className="text-[0.3em] align-top text-slate-400"> dtk</span>
      </div>
      <div className="w-full max-w-xl h-3 md:h-4 bg-slate-800 rounded-full overflow-hidden mt-2 border border-slate-700">
        <div
          className={cn('h-full rounded-full transition-all duration-200',
            danger ? 'bg-red-500' : warn ? 'bg-amber-400' : 'bg-emerald-400')}
          style={{ width: `${pct * 100}%` }}
        />
      </div>
    </div>
  );
}
