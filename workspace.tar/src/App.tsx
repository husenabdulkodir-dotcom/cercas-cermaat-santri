import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Landing from './pages/Landing';
import Stage from './pages/Stage';
import Admin from './pages/Admin';
import BuzzerRemote from './pages/BuzzerRemote';

// Rute:
//   /                      -> Landing (pilih mode & masuk kode ruangan)
//   /stage/:roomId         -> LAYAR PROYEKTOR (penonton & juri melihat)
//   /admin/:roomId         -> PANEL ADMIN JURI (buka soal, timer, nilai)
//   /bel/:roomId           -> Bel darurat via HP/tablet (opsional, tetap offline-LAN)
export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/stage/:roomId" element={<Stage />} />
        <Route path="/admin/:roomId" element={<Admin />} />
        <Route path="/bel/:roomId" element={<BuzzerRemote />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
