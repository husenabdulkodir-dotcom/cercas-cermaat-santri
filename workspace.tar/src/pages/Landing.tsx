import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MonitorPlay, SlidersHorizontal, Volume2, Wifi, Maximize } from 'lucide-react';
import { sounds } from '../lib/audio';

export default function Landing() {
  const nav = useNavigate();
  const [room, setRoom] = useState('lomba');
  const [serverInfo, setServerInfo] = useState<{ ips: string[]; port: number } | null>(null);

  useEffect(() => {
    fetch('/api/ip').then((r) => r.ok ? r.json() : null).then(setServerInfo).catch(() => {});
  }, []);

  // Klik mana pun membuka kunci audio (kebijakan autoplay browser).
  const unlockAndGo = (path: string) => {
    sounds.unlock();
    nav(path.replace(':r', room.trim().toLowerCase() || 'lomba'));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-950 via-slate-950 to-teal-950 text-white flex items-center justify-center p-6" onClick={() => sounds.unlock()}>
      <div className="w-full max-w-3xl">
        <div className="text-center mb-8">
          <p className="text-amber-400 font-bold tracking-[0.3em] uppercase text-sm mb-2">Lomba Cerdas Cermat</p>
          <h1 className="text-4xl md:text-6xl font-black bg-gradient-to-r from-emerald-300 via-amber-300 to-emerald-300 bg-clip-text text-transparent">
            CERDAS CERMAT SANTRI
          </h1>
          <p className="text-slate-400 mt-3 flex items-center justify-center gap-2">
            <Wifi size={16} /> Mode OFFLINE — cukup 1 laptop + proyektor, tanpa internet / tanpa HP peserta
          </p>
        </div>

        <div className="bg-slate-900/70 border border-slate-700 rounded-3xl p-6 md:p-8 shadow-2xl backdrop-blur">
          <label className="block text-xs uppercase tracking-widest text-slate-400 font-bold mb-2">Kode Ruangan</label>
          <input
            value={room}
            onChange={(e) => setRoom(e.target.value)}
            className="w-full bg-slate-800 border-2 border-slate-600 focus:border-emerald-400 outline-none rounded-xl px-4 py-3 text-xl font-mono mb-6"
            placeholder="lomba"
          />

          <div className="grid md:grid-cols-2 gap-4">
            <button onClick={() => unlockAndGo('/stage/:r')} className="group p-5 rounded-2xl bg-gradient-to-br from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 transition text-left cursor-pointer">
              <MonitorPlay className="mb-3 group-hover:scale-110 transition" size={32} />
              <h2 className="font-black text-lg">LAYAR PROYEKTOR</h2>
              <p className="text-emerald-100/80 text-sm">Buka di laptop yang tersambung ke proyektor / TV besar.</p>
            </button>

            <button onClick={() => unlockAndGo('/admin/:r')} className="group p-5 rounded-2xl bg-gradient-to-br from-amber-600 to-orange-700 hover:from-amber-500 hover:to-orange-600 transition text-left cursor-pointer">
              <SlidersHorizontal className="mb-3 group-hover:scale-110 transition" size={32} />
              <h2 className="font-black text-lg">PANEL ADMIN JURI</h2>
              <p className="text-amber-100/80 text-sm">Buka di laptop panitia: bacakan soal, timer, beri nilai.</p>
            </button>
          </div>

          <div className="mt-6 grid md:grid-cols-2 gap-3 text-sm">
            <button onClick={() => unlockAndGo('/bel/:r')} className="flex items-center gap-2 px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 hover:border-rose-400 transition cursor-pointer">
              <Volume2 size={18} className="text-rose-400" /> Bel Darurat via HP/Tablet (opsional, tetap LAN)
            </button>
            <a href="#" onClick={(e) => { e.preventDefault(); document.documentElement.requestFullscreen?.(); }} className="flex items-center gap-2 px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 hover:border-emerald-400 transition cursor-pointer">
              <Maximize size={18} className="text-emerald-400" /> Layar Penuh (F11 juga bisa)
            </a>
          </div>

          {serverInfo?.ips?.length ? (
            <p className="mt-6 text-xs text-slate-400 font-mono bg-slate-800/60 rounded-lg p-3">
              Alamat utk device kedua (satu WiFi/LAN pondok):{' '}
              {serverInfo.ips.map((ip) => (
                <span key={ip} className="text-emerald-300">http://{ip}:{serverInfo.port}/stage/{room.toLowerCase() || 'lomba'}&nbsp;&nbsp;</span>
              ))}
            </p>
          ) : null}
        </div>

        <p className="text-center text-xs text-slate-500 mt-6">
          💡 Saran hari-H: Admin &amp; Proyektor buka URL yang sama di 2 laptop. Bila hanya 1 laptop, gunakan 2 monitor (extend) — satu Stage, satu Admin.
        </p>
      </div>
    </div>
  );
}
