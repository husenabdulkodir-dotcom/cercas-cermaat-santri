import { useEffect, useMemo, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useGameState, setSocketRole } from '../lib/useGameState';
import { socket } from '../lib/socket';
import { sounds } from '../lib/audio';
import { TYPE_LABEL, Question } from '../types';
import BigTimer from '../components/BigTimer';
import EnvelopeSelector from '../components/EnvelopeSelector';
import PodiumView from '../components/PodiumView';
import CelebrationEffects from '../components/CelebrationEffects';
import AudioVisualizer from '../components/AudioVisualizer';
import { resolveAsset, cn } from '../lib/utils';
import { Trophy, WifiOff, Volume2, Radio } from 'lucide-react';

export default function Stage() {
  const { roomId = 'lomba' } = useParams();
  setSocketRole('stage');
  const { state, connected } = useGameState(roomId);
  const [audioPlaying, setAudioPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const lastSecRef = useRef<number>(-1);
  const [unlocked, setUnlocked] = useState(false);

  // === Suara & TTS hanya di STAGE (satu sumber suara utk seluruh aula) =====
  // Bel: dibunyikan HANYA bila event ini berasal dari regu yang akhirnya
  // menjadi pemenang tekan (memperbaiki bug versi lama: semua HP berbunyi).
  useEffect(() => {
    const onBuzz = (ev: { groupId: string; at: number }) => {
      if (!state) return;
      if (state.buzzedGroupId !== ev.groupId) return; // bukan yg paling cepat → diam
      sounds.playBuzzer();
    };
    const onExpired = () => {
      sounds.playTimesUp();
      sounds.speak('Waktu habis!', { lang: state?.settings.ttsVoice === 'off' ? undefined : state?.settings.ttsVoice });
    };
    socket.on('buzz-event', onBuzz);
    socket.on('timer-expired', onExpired);
    return () => {
      socket.off('buzz-event', onBuzz);
      socket.off('timer-expired', onExpired);
    };
  }, [state]);

  // Hitungan mundur bersuara + tick tiap detik saat <=10 dtk tersisa.
  useEffect(() => {
    if (!state?.isTimerRunning || !state.timerEndsAt) return;
    const id = setInterval(() => {
      const left = Math.max(0, Math.ceil((state.timerEndsAt! - Date.now()) / 1000));
      if (left === lastSecRef.current) return;
      lastSecRef.current = left;
      if (left <= 10 && left > 0) {
        sounds.playTick();
        if (state.settings.speakCountdown && state.settings.ttsVoice !== 'off') {
          sounds.speakCountdownNumber(left, state.settings.ttsVoice);
        }
      }
    }, 200);
    return () => clearInterval(id);
  }, [state?.isTimerRunning, state?.timerEndsAt, state?.settings.speakCountdown, state?.settings.ttsVoice]);

  // Auto-play audio soal (qiroah/nasyid) — butuh unlock klik pertama.
  useEffect(() => {
    if (!state?.activeQuestion) { setAudioPlaying(false); return; }
    const src = resolveAsset(state.activeQuestion.audioUrl);
    if (!src || (state.activeQuestion.type !== 'audio')) return;
    if (!unlocked) return; // tunggu user mengklik stage sekali
    const a = new Audio(src);
    audioRef.current = a;
    a.onended = () => setAudioPlaying(false);
    a.onerror = () => setAudioPlaying(false);
    a.play().then(() => setAudioPlaying(true)).catch(() => setAudioPlaying(false));
    return () => { a.pause(); };
  }, [state?.activeQuestion?.id, unlocked]);

  // Bacakan soal via TTS saat soal baru tampil (kecuali audio/gambar).
  const spokenForRef = useRef<string | null>(null);
  useEffect(() => {
    if (!state?.activeQuestion || state.settings.ttsVoice === 'off' || !unlocked) return;
    const q = state.activeQuestion;
    if (spokenForRef.current === q.id) return;
    if (q.type === 'audio' || q.type === 'gambar') return; // biar MC/pemimpin acara yang bacakan
    spokenForRef.current = q.id;
    const text = q.type === 'clue' ? `${q.text} Petunjuk pertama: ${q.clues?.[0] ?? ''}` : q.text;
    sounds.speak(text, { lang: 'id', rate: 0.95 });
  }, [state?.activeQuestion?.id, unlocked, state?.settings.ttsVoice]);

  const rankedGroups = useMemo(
    () => (state?.groups ? [...state.groups].sort((a, b) => b.score - a.score) : []),
    [state?.groups],
  );

  if (!state) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center text-xl">
        Menghubungkan ke server lomba… <span className="ml-2 animate-ping">●</span>
      </div>
    );
  }

  const q: Question | null = state.activeQuestion;
  const buzzWinner = state.groups.find((g) => g.id === state.buzzedGroupId);

  return (
    <div
      className="min-h-screen bg-gradient-to-br from-emerald-950 via-slate-950 to-teal-950 text-white flex flex-col overflow-hidden"
      onClick={() => { sounds.unlock(); setUnlocked(true); }}
    >
      {!connected && (
        <div className="absolute top-3 right-3 z-50 flex items-center gap-2 bg-red-600/90 px-3 py-1.5 rounded-lg text-sm font-bold">
          <WifiOff size={16} /> Koneksi terputus — menunggu server…
        </div>
      )}
      {!unlocked && (
        <div className="absolute bottom-3 right-3 z-50 flex items-center gap-2 bg-amber-500/90 text-slate-900 px-3 py-1.5 rounded-lg text-xs font-bold animate-pulse">
          <Volume2 size={14} /> Klik layar sekali utk mengaktifkan SUARA
        </div>
      )}

      {/* ================= HEADER ================= */}
      <header className="flex items-center justify-between px-6 py-3 border-b border-emerald-800/50 bg-slate-950/60 backdrop-blur">
        <h1 className="font-black text-lg md:text-2xl tracking-wide text-emerald-300">🕌 CERDAS CERMAT SANTRI</h1>
        <div className={cn('px-4 py-1 rounded-full font-black uppercase text-sm md:text-base border',
          state.gamePhase === 'Pengumuman' ? 'bg-amber-500 text-slate-900 border-amber-300' : 'bg-emerald-600/30 text-emerald-300 border-emerald-500/50')}>
          {state.gamePhase}
        </div>
        <span className="font-mono text-slate-400 text-sm">Ruang: {state.roomId}</span>
      </header>

      {/* ================= Papan skor mini (selalu terlihat) ================= */}
      {state.gamePhase !== 'Pengumuman' && state.groups.length > 0 && (
        <div className="px-4 pt-3">
          <div className="flex gap-2 overflow-x-auto pb-1">
            {rankedGroups.map((g) => {
              const isWinner = state.buzzedGroupId === g.id;
              const isTurn = state.activeTurnGroupId === g.id;
              return (
                <div key={g.id}
                  className={cn('shrink-0 px-3 py-1.5 rounded-xl border text-sm flex items-center gap-2 transition-all',
                    isWinner || isTurn
                      ? 'bg-emerald-500 text-slate-950 font-black border-white pulse-ring buzz-pop'
                      : 'bg-slate-800/80 border-slate-700 text-slate-200')}>
                  <Trophy size={14} className={isWinner || isTurn ? 'text-slate-900' : 'text-amber-400'} />
                  <span>{g.name}</span>
                  <b className="font-mono">{g.score}</b>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ================= ISI ================= */}
      <main className="flex-1 relative flex flex-col">
        {state.gamePhase === 'Pengumuman' ? (
          <>
            <CelebrationEffects />
            <PodiumView groups={state.groups} />
          </>
        ) : state.gamePhase === 'Soal Wajib' && !q ? (
          <EnvelopeSelector
            questions={state.questions}
            groups={state.groups}
            activeTurnGroupId={state.activeTurnGroupId}
            openedEnvelope={state.openedEnvelope}
          />
        ) : (
          <div className="flex-1 grid lg:grid-cols-[1fr_auto] gap-6 p-6 max-w-7xl w-full mx-auto">
            {/* --- Panel soal --- */}
            <section className="flex flex-col justify-center">
              {q ? (
                <div className="space-y-5">
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="px-4 py-1 rounded-full bg-amber-500 text-slate-950 font-black text-sm uppercase">{TYPE_LABEL[q.type]}</span>
                    <span className="px-4 py-1 rounded-full bg-slate-800 border border-slate-600 text-emerald-300 font-bold text-sm">{q.category}</span>
                    <span className="px-4 py-1 rounded-full bg-emerald-900/60 border border-emerald-500/40 text-emerald-200 font-bold text-sm">{q.points} POIN</span>
                  </div>

                  <p className={cn('font-bold leading-snug text-white', q.text.length > 120 ? 'text-2xl md:text-4xl' : 'text-3xl md:text-5xl')}
                     style={{ textShadow: '0 2px 20px rgba(0,0,0,.6)' }}>
                    {q.text}
                  </p>

                  {/* Pilihan ganda */}
                  {q.options && (
                    <ul className="grid md:grid-cols-2 gap-3 text-lg md:text-2xl font-semibold">
                      {q.options.map((o, i) => (
                        <li key={i} className="bg-slate-800/80 border border-slate-600 rounded-xl px-4 py-3">{o}</li>
                      ))}
                    </ul>
                  )}

                  {/* Clue bertingkat */}
                  {q.type === 'clue' && q.clues && (
                    <ul className="space-y-2 text-xl md:text-2xl">
                      {q.clues.slice(0, state.activeClueIndex + 1).map((c, i) => (
                        <li key={i} className="bg-sky-950/70 border border-sky-500/40 rounded-xl px-4 py-3 flex gap-3">
                          <span className="text-sky-400 font-black">{i + 1}.</span> {c}
                        </li>
                      ))}
                    </ul>
                  )}

                  {/* Audio visualizer */}
                  {(q.type === 'audio') && (
                    <div className="flex items-center gap-3 bg-slate-800/70 border border-slate-600 rounded-2xl p-4 w-fit">
                      <Radio className="text-rose-400 animate-pulse" />
                      <AudioVisualizer playing={audioPlaying} />
                      <span className="text-slate-300 font-bold">{audioPlaying ? 'Memutar audio soal…' : 'Siap memutar audio'}</span>
                    </div>
                  )}

                  {/* Gambar soal (tebak gambar) */}
                  {q.questionImage && (
                    <img src={resolveAsset(q.questionImage)} alt="Gambar soal"
                      className="max-h-[46vh] rounded-2xl border-4 border-slate-700 shadow-2xl object-contain bg-slate-900" />
                  )}

                  {/* Jawaban */}
                  {state.revealAnswer ? (
                    <div className="buzz-pop mt-2 p-5 rounded-2xl bg-gradient-to-br from-emerald-600 to-teal-700 border-2 border-emerald-300 shadow-2xl">
                      <p className="text-emerald-200 text-xs font-black uppercase tracking-widest mb-1">Jawaban</p>
                      <p className="text-3xl md:text-4xl font-black text-white">{q.answer}</p>
                      {q.answerImage && <img src={resolveAsset(q.answerImage)} alt="Pembahasan" className="mt-3 max-h-64 rounded-xl border border-white/30" />}
                    </div>
                  ) : buzzWinner ? (
                    <div className="buzz-pop p-4 rounded-2xl bg-rose-600/90 border-2 border-rose-300 inline-block">
                      <p className="text-rose-100 text-xs font-black uppercase tracking-widest">Bel tercepat</p>
                      <p className="text-3xl font-black text-white">🔔 {buzzWinner.name}</p>
                    </div>
                  ) : state.buzzerEnabled ? (
                    <p className="text-amber-300 font-bold animate-pulse">🔔 Silakan tekan bel…</p>
                  ) : null}
                </div>
              ) : (
                <div className="text-center space-y-4">
                  <p className="text-4xl md:text-6xl font-black text-slate-300">Menunggu soal dari Dewan Juri…</p>
                  <p className="text-slate-500">MC dapat memulai dengan membacakan basmalah 🌙</p>
                </div>
              )}
            </section>

            {/* --- Timer raksasa sisi kanan --- */}
            <aside className="lg:w-[380px] flex flex-col items-center justify-center gap-6">
              <BigTimer
                durationSec={state.timerDurationSec}
                endsAt={state.timerEndsAt}
                isRunning={state.isTimerRunning}
                frozenLeft={state.timeLeftOverride}
              />
              {state.spinWheelResult && (
                <div className="px-4 py-2 rounded-xl bg-purple-600/40 border border-purple-400 font-black text-purple-200">
                  Roda: {state.spinWheelResult}
                </div>
              )}
            </aside>
          </div>
        )}
      </main>
    </div>
  );
}
