import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useGameState, setSocketRole } from '../lib/useGameState';
import { socket } from '../lib/socket';
import { sounds } from '../lib/audio';
import { GamePhase, PHASES, Question, QuestionType, TYPE_LABEL } from '../types';
import { defaultQuestions } from '../data/defaultQuestions';
import EnvelopeSelector from '../components/EnvelopeSelector';
import SpinWheel from '../components/SpinWheel';
import BigTimer from '../components/BigTimer';
import { cn, resolveAsset } from '../lib/utils';
import * as XLSX from 'xlsx';
import {
  Play, Pause, RotateCcw, Eye, EyeOff, CheckCircle2, XCircle, SkipForward,
  Users, BookOpen, Settings, ListOrdered, Download, Upload, Plus, Trash2,
  Zap, Volume2, MessageSquare, ArrowLeftRight, Timer as TimerIcon,
} from 'lucide-react';

type Tab = 'permainan' | 'regu' | 'soal' | 'pengaturan' | 'log';

export default function Admin() {
  // state utk helper di bawah; selalu dicek null sebelum dipakai.
  const { roomId = 'lomba' } = useParams();
  setSocketRole('admin');
  const { state, connected } = useGameState(roomId);
  const [tab, setTab] = useState<Tab>('permainan');
  const [expr, setExpr] = useState<Record<string, string>>({});
  const fileRef = useRef<HTMLInputElement>(null);
  const [draft, setDraft] = useState<Question | null>(null);

  // ---------------- Keyboard shortcuts (hari-H tanpa mouse) ----------------
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!state) return;
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      const k = e.key.toLowerCase();
      if (k === ' ') { e.preventDefault(); state.isTimerRunning ? socket.emit('timer:pause') : socket.emit('timer:start'); }
      else if (k === 'r') socket.emit('timer:reset');
      else if (k === 'j') socket.emit('answer:reveal', !state.revealAnswer);
      else if (k === 'n') socket.emit('question:finish');
      else if (k === 'c') socket.emit('clue:next');
      else if (/^[1-9]$/.test(k)) {
        const g = state.groups[Number(k) - 1];
        if (g) award(g.id, state.activeQuestion?.points ?? 10);
      } else if (k === 'x') {
        const g = state.groups[state.groups.length - 1]; // X = regu terakhir gagal lempar
        if (g && state.activeQuestion?.type === 'lempar') socket.emit('lempar:failed', g.id);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [state]);

  const award = (groupId: string, points: number) => {
    socket.emit('group:score', groupId, points);
    sounds.playCorrect();
  };

  // ---------------- Daftar soal per fase ----------------
  const packetFilter = state?.openedEnvelope;
  const phaseTypes: Record<GamePhase, QuestionType[]> = useMemo(() => ({
    'Persiapan': [],
    'Soal Wajib': ['wajib'],
    'Soal Lempar': ['lempar'],
    'Soal Rebutan': ['rebutan', 'pilihan_ganda', 'clue'],
    'Soal Bonus': ['audio', 'gambar'],
    'Pengumuman': [],
  }), []);

  const queue = useMemo(() => {
    if (!state) return [];
    const types = phaseTypes[state.gamePhase];
    return state.questions.filter((q) =>
      types.includes(q.type) &&
      (!packetFilter || q.type !== 'wajib' || q.packet === packetFilter) &&
      !state.usedQuestionIds.includes(q.id),
    );
  }, [state, phaseTypes, packetFilter]);

  if (!state) {
    return <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center text-xl">Menghubungkan ke server…</div>;
  }

  // Snapshot non-null utk helper di bawah (setelah guard if(!state))
  const st = state;
  const q = state.activeQuestion;
  const buzzOrder = state.buzzQueue.map((b, i) => ({ ...b, rank: i + 1, group: state.groups.find((g) => g.id === b.groupId) }));

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Header */}
      <header className="flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-slate-900 sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <span className={cn('w-2.5 h-2.5 rounded-full', connected ? 'bg-emerald-400' : 'bg-red-500 animate-pulse')} />
          <h1 className="font-black text-lg">PANEL JURI — {state.roomId}</h1>
        </div>
        <nav className="flex gap-1 text-sm">
          {([['permainan', 'Permainan', Zap], ['regu', 'Regu', Users], ['soal', 'Bank Soal', BookOpen], ['pengaturan', 'Aturan', Settings], ['log', 'Log Juri', ListOrdered]] as const).map(([id, label, Icon]) => (
            <button key={id} onClick={() => setTab(id)}
              className={cn('flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold cursor-pointer',
                tab === id ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700')}>
              {/* @ts-ignore */}
              <Icon size={15} /> {label}
            </button>
          ))}
        </nav>
      </header>

      <main className="p-4 flex-1">
        {/* ================= TAB PERMAINAN ================= */}
        {tab === 'permainan' && (
          <div className="grid lg:grid-cols-[1fr_360px] gap-4 max-w-7xl mx-auto">
            <div className="space-y-4">
              {/* Fase */}
              <section className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
                <h2 className="font-black text-slate-400 uppercase text-xs tracking-widest mb-2">Fase Lomba</h2>
                <div className="flex flex-wrap gap-2">
                  {PHASES.map((p) => (
                    <button key={p} onClick={() => socket.emit('phase:set', p)}
                      className={cn('px-4 py-2 rounded-xl font-bold text-sm cursor-pointer transition',
                        state.gamePhase === p ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 hover:bg-slate-700')}>
                      {p}
                    </button>
                  ))}
                </div>
                {state.gamePhase === 'Soal Wajib' && !q && (
                  <div className="mt-4">
                    <EnvelopeSelector questions={state.questions} groups={state.groups}
                      activeTurnGroupId={state.activeTurnGroupId} openedEnvelope={state.openedEnvelope}
                      onSelectEnvelope={(pkt) => { socket.emit('envelope:open', pkt); sounds.playEnvelope(); }} />
                  </div>
                )}
                {state.gamePhase === 'Soal Bonus' && !q && (
                  <div className="mt-4 flex justify-center">
                    <SpinWheel segments={state.groups.map((g) => g.name)}
                      onResult={(label) => {
                        const g = state.groups.find((x) => x.name === label);
                        if (g) { socket.emit('turn:set', g.id); socket.emit('spin:result', `${label} dapat giliran bonus`); }
                      }} />
                  </div>
                )}
              </section>

              {/* Antrean soal fase ini */}
              <section className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
                <h2 className="font-black text-slate-400 uppercase text-xs tracking-widest mb-2">
                  Antrean Soal — {state.gamePhase} {packetFilter ? `(${packetFilter})` : ''} · sisa {queue.length}
                </h2>
                {queue.length === 0 ? (
                  <p className="text-slate-500 text-sm">Tidak ada soal tersisa utk fase ini. Ganti fase atau muat bank soal.</p>
                ) : (
                  <ul className="space-y-2 max-h-56 overflow-y-auto">
                    {queue.map((qq) => (
                      <li key={qq.id} className="flex items-center gap-3 bg-slate-800/70 rounded-xl px-3 py-2">
                        <span className="text-[10px] font-black uppercase bg-slate-700 px-2 py-0.5 rounded-md text-amber-300 w-24 truncate">{TYPE_LABEL[qq.type]}</span>
                        <span className="flex-1 text-sm truncate">{qq.text}</span>
                        <span className="text-xs text-slate-400">{qq.points} pt</span>
                        <button onClick={() => socket.emit('question:start', qq.id)}
                          className="bg-emerald-600 hover:bg-emerald-500 px-3 py-1.5 rounded-lg text-xs font-black cursor-pointer">▶ Tampilkan</button>
                      </li>
                    ))}
                  </ul>
                )}
              </section>

              {/* Kontrol soal aktif */}
              {q && (
                <section className="bg-slate-900 border border-emerald-800/60 rounded-2xl p-4 space-y-3">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="px-3 py-1 rounded-full bg-amber-500 text-slate-950 text-xs font-black uppercase">{TYPE_LABEL[q.type]}</span>
                    <span className="text-slate-400 text-sm">{q.category} · {q.points} poin</span>
                  </div>
                  <p className="font-semibold text-lg leading-snug">{q.text}</p>
                  {q.questionImage && <img src={resolveAsset(q.questionImage)} className="max-h-48 rounded-xl border border-slate-700" alt="" />}
                  {q.options && <ul className="grid grid-cols-2 gap-2 text-sm">{q.options.map((o, i) => <li key={i} className="bg-slate-800 rounded-lg px-3 py-2">{o}</li>)}</ul>}
                  {q.type === 'clue' && q.clues && (
                    <ul className="text-sm space-y-1">
                      {q.clues.slice(0, state.activeClueIndex + 1).map((c, i) => <li key={i} className="bg-sky-950 rounded-lg px-3 py-2 border border-sky-800">{i + 1}. {c}</li>)}
                    </ul>
                  )}
                  <div className={cn('rounded-xl px-4 py-3 border-2 font-bold', state.revealAnswer ? 'bg-emerald-950 border-emerald-500 text-emerald-200' : 'bg-slate-800 border-slate-700 text-slate-300')}>
                    🔑 Jawaban: {state.revealAnswer ? q.answer : '──── (tekan J / Sembunyikan)'}
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {q.type === 'clue' && <Btn onClick={() => socket.emit('clue:next')} icon={ArrowLeftRight} label="Clue Berikutnya" color="bg-sky-600" />}
                    <Btn onClick={() => socket.emit('answer:reveal', !state.revealAnswer)} icon={state.revealAnswer ? EyeOff : Eye} label={state.revealAnswer ? 'Sembunyi Jawaban' : 'Tampil Jawaban'} color="bg-slate-700" />
                    {q.type === 'lempar' && state.activeTurnGroupId && (
                      <Btn onClick={() => socket.emit('turn:pass', state.activeTurnGroupId)} icon={SkipForward} label={`Lempar ke regu lain (-${state.settings.penaltyLempar})`} color="bg-purple-600" />
                    )}
                    {q.type === 'lempar' && state.activeTurnGroupId && (
                      <Btn onClick={() => { socket.emit('lempar:failed', state.activeTurnGroupId!); sounds.playWrong(); }} icon={XCircle} label="Gagal (penalti)" color="bg-rose-700" />
                    )}
                    <Btn onClick={() => { socket.emit('question:finish'); sounds.stopSpeaking(); }} icon={CheckCircle2} label="Selesai Soal (N)" color="bg-emerald-700" />
                  </div>

                  {/* Giliran & pemberian nilai cepat */}
                  <div className="border-t border-slate-800 pt-3">
                    <p className="text-xs font-black uppercase text-slate-400 mb-2">
                      {q.type === 'lempar' || q.type === 'wajib' ? 'Giliran / Amplop:' : 'Bel masuk (urut tercepat):'}
                    </p>
                    {q.type === 'rebutan' || q.type === 'audio' || q.type === 'gambar' || q.type === 'pilihan_ganda' ? (
                      buzzOrder.length === 0 ? <p className="text-slate-500 text-sm">Belum ada bel… (bell {state.buzzerEnabled ? 'AKTIF ✅' : 'terkunci'})</p> : (
                        <ol className="space-y-1 mb-2">
                          {buzzOrder.map((b) => (
                            <li key={b.groupId} className={cn('flex items-center gap-2 text-sm', b.rank === 1 ? 'text-emerald-300 font-black' : 'text-slate-400')}>
                              #{b.rank} 🔔 {b.group?.name} <span className="font-mono text-xs">+{(b.at - buzzOrder[0].at)}ms</span>
                            </li>
                          ))}
                        </ol>
                      )
                    ) : (
                      <div className="flex flex-wrap gap-1.5 mb-2">
                        {state.groups.map((g) => (
                          <button key={g.id} onClick={() => socket.emit('turn:set', g.id)}
                            className={cn('px-3 py-1 rounded-lg text-xs font-bold cursor-pointer',
                              state.activeTurnGroupId === g.id ? 'bg-emerald-600 text-white' : 'bg-slate-800 hover:bg-slate-700')}>
                            {g.name}{state.passedGroupIds.includes(g.id) ? ' ✔lewat' : ''}
                          </button>
                        ))}
                      </div>
                    )}
                    {/* tombol nilai per regu */}
                    <div className="grid sm:grid-cols-2 gap-2">
                      {state.groups.map((g, idx) => (
                        <div key={g.id} className="flex items-center gap-2 bg-slate-800/80 rounded-xl px-2.5 py-2">
                          <span className="text-[10px] font-mono text-slate-500 w-4">{idx + 1}</span>
                          <span className="flex-1 text-sm font-bold truncate">{g.name}</span>
                          <span className="font-mono text-amber-300 font-black">{g.score}</span>
                          <input
                            value={expr[g.id] ?? ''}
                            onChange={(e) => setExpr({ ...expr, [g.id]: e.target.value })}
                            onKeyDown={(e) => { if (e.key === 'Enter') { applyExpr(g.id); } }}
                            placeholder={`${q.points}`} className="w-16 bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs" />
                          <button onClick={() => applyExpr(g.id)} className="bg-emerald-600 rounded-lg px-2 py-1 text-xs font-black cursor-pointer">+</button>
                          <button onClick={() => applyExpr(g.id, true)} className="bg-rose-700 rounded-lg px-2 py-1 text-xs font-black cursor-pointer">−</button>
                        </div>
                      ))}
                    </div>
                  </div>
                </section>
              )}
            </div>

            {/* Kolom kanan: timer besar mini + status */}
            <aside className="space-y-4">
              <section className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col items-center gap-3">
                <TimerIcon className="text-emerald-400" />
                <BigTimer durationSec={state.timerDurationSec} endsAt={state.timerEndsAt} isRunning={state.isTimerRunning} frozenLeft={state.timeLeftOverride} />
                <div className="flex gap-2">
                  <Btn onClick={() => socket.emit(state.isTimerRunning ? 'timer:pause' : 'timer:start')} icon={state.isTimerRunning ? Pause : Play}
                    label={state.isTimerRunning ? 'Jeda (Spasi)' : 'Mulai (Spasi)'} color={state.isTimerRunning ? 'bg-amber-600' : 'bg-emerald-600'} />
                  <Btn onClick={() => socket.emit('timer:reset')} icon={RotateCcw} label="Reset (R)" color="bg-slate-700" />
                </div>
                <div className="flex gap-2">
                  <button onClick={() => socket.emit('timer:adjust', -5)} className="px-3 py-1 rounded-lg bg-slate-800 text-xs font-bold cursor-pointer">−5 dtk</button>
                  <button onClick={() => socket.emit('timer:adjust', 5)} className="px-3 py-1 rounded-lg bg-slate-800 text-xs font-bold cursor-pointer">+5 dtk</button>
                  <button onClick={() => socket.emit('timer:adjust', 10)} className="px-3 py-1 rounded-lg bg-slate-800 text-xs font-bold cursor-pointer">+10 dtk</button>
                </div>
              </section>

              <section className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2">
                <h3 className="text-xs font-black uppercase text-slate-400 flex items-center gap-2"><Volume2 size={14} /> Suara Stage</h3>
                <p className="text-xs text-slate-500">Semua efek suara &amp; pembacaan TTS keluar dari laptop PROYEKTOR. Pastikan stage sudah diklik sekali.</p>
                <button onClick={() => { socket.emit('buzzer:toggle', !state.buzzerEnabled); }}
                  className={cn('w-full py-2 rounded-xl font-black text-sm cursor-pointer', state.buzzerEnabled ? 'bg-emerald-600' : 'bg-rose-700')}>
                  Bel Rebutan: {state.buzzerEnabled ? 'AKTIF — klik utk kunci' : 'KUNCI — klik utk buka'}
                </button>
                <button onClick={() => socket.emit('buzzer:clear')} className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-sm font-bold cursor-pointer">Bersihkan daftar bel</button>
              </section>
            </aside>
          </div>
        )}

        {/* ================= TAB REGU ================= */}
        {tab === 'regu' && (
          <div className="max-w-3xl mx-auto space-y-4">
            <AddGroupForm />
            <div className="bg-slate-900 border border-slate-800 rounded-2xl divide-y divide-slate-800">
              {state.groups.map((g, i) => (
                <div key={g.id} className="flex items-center gap-3 px-4 py-3">
                  <span className="font-mono text-slate-500">#{i + 1}</span>
                  <input defaultValue={g.name} onBlur={(e) => e.target.value !== g.name && socket.emit('group:rename', g.id, e.target.value)}
                    className="flex-1 bg-transparent border-b border-transparent focus:border-emerald-500 outline-none font-bold" />
                  <span className="text-xs font-mono px-2 py-1 bg-slate-800 rounded-lg text-amber-300" title="Kode tombol keypad/bel cadangan">⌨ {g.id}</span>
                  <input type="number" value={g.score} onChange={(e) => socket.emit('group:setScore', g.id, Number(e.target.value))}
                    className="w-24 bg-slate-800 border border-slate-700 rounded-lg px-2 py-1 font-mono font-black text-right" />
                  <button onClick={() => confirm(`Hapus ${g.name}?`) && socket.emit('group:remove', g.id)}
                    className="text-rose-500 hover:text-rose-400 cursor-pointer"><Trash2 size={18} /></button>
                </div>
              ))}
              {!state.groups.length && <p className="p-6 text-center text-slate-500">Belum ada regu. Tambahkan di atas (maks disarankan 15).</p>}
            </div>
            <div className="flex gap-2">
              <Btn onClick={() => confirm('RESET skor semua regu ke 0?') && socket.emit('groups:resetScores')} icon={RotateCcw} label="Reset Semua Skor" color="bg-rose-800" />
              <Btn onClick={exportResults} icon={Download} label="Unduh Hasil (XLSX)" color="bg-sky-700" />
            </div>
          </div>
        )}

        {/* ================= TAB BANK SOAL ================= */}
        {tab === 'soal' && (
          <div className="max-w-5xl mx-auto space-y-4">
            <div className="flex flex-wrap gap-2 items-center">
              <Btn onClick={() => socket.emit('questions:replaceAll', defaultQuestions)} icon={RotateCcw} label="Muat Bank Bawaan (20 soal)" color="bg-slate-700" />
              <Btn onClick={() => fileRef.current?.click()} icon={Upload} label="Impor XLSX/CSV/JSON" color="bg-sky-700" />
              <Btn onClick={exportQuestions} icon={Download} label="Ekspor JSON (cadangan)" color="bg-emerald-700" />
              <Btn onClick={() => setDraft(blankQuestion())} icon={Plus} label="Tambah Soal" color="bg-amber-600" />
              <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv,.json" className="hidden" onChange={onImportFile} />
            </div>
            <p className="text-xs text-slate-500">💾 Bank soal tersimpan permanen di server (snapshot). Gambar/audio cukup tulis nama file — taruh filenya di folder <code className="bg-slate-800 px-1 rounded">./media/</code>.</p>
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-slate-800 text-slate-400 text-left">
                  <tr>{['Tipe', 'Amplop', 'Kategori', 'Soal', 'Poin', 'Pakai?', ''].map((h) => <th key={h} className="px-3 py-2 font-black text-xs uppercase">{h}</th>)}</tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {state.questions.map((qq) => (
                    <tr key={qq.id} className={cn('hover:bg-slate-800/50', state.usedQuestionIds.includes(qq.id) && 'opacity-40')}>
                      <td className="px-3 py-2"><span className="text-[10px] font-black uppercase bg-slate-700 px-2 py-0.5 rounded text-amber-300">{TYPE_LABEL[qq.type]}</span></td>
                      <td className="px-3 py-2">{qq.packet ?? '-'}</td>
                      <td className="px-3 py-2">{qq.category}</td>
                      <td className="px-3 py-2 max-w-md truncate" title={qq.text}>{qq.text}</td>
                      <td className="px-3 py-2 font-mono">{qq.points}</td>
                      <td className="px-3 py-2">{state.usedQuestionIds.includes(qq.id) ? '✅' : '—'}</td>
                      <td className="px-3 py-2 whitespace-nowrap">
                        <button onClick={() => setDraft(qq)} className="text-sky-400 mr-2 cursor-pointer">✏️</button>
                        <button onClick={() => confirm('Hapus soal ini?') && socket.emit('question:delete', qq.id)} className="text-rose-400 cursor-pointer">🗑</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {draft && <QuestionEditor draft={draft} setDraft={setDraft} onClose={() => setDraft(null)} />}
          </div>
        )}

        {/* ================= TAB PENGATURAN ================= */}
        {tab === 'pengaturan' && (
          <div className="max-w-2xl mx-auto bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <h2 className="font-black text-lg">Aturan Waktu &amp; Poin</h2>
            {([['wajibSec', 'Waktu Soal Wajib (dtk)'], ['lemparSec', 'Waktu Soal Lempar (dtk)'], ['rebutanSec', 'Waktu Soal Rebutan (dtk)'], ['bonusSec', 'Waktu Soal Bonus/Gambar (dtk)'], ['penaltyLempar', 'Penalti gagal lemparan (poin)']] as const).map(([key, label]) => (
              <label key={key} className="flex items-center justify-between gap-4">
                <span className="text-sm font-bold text-slate-300">{label}</span>
                <input type="number" min={1} value={state.settings[key]}
                  onChange={(e) => socket.emit('settings:update', { [key]: Math.max(0, Number(e.target.value) || 0) })}
                  className="w-24 bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 font-mono text-right" />
              </label>
            ))}
            <label className="flex items-center justify-between">
              <span className="text-sm font-bold text-slate-300">Hitungan mundur bersuara (TTS)</span>
              <input type="checkbox" checked={state.settings.speakCountdown} onChange={(e) => socket.emit('settings:update', { speakCountdown: e.target.checked })} className="w-5 h-5 accent-emerald-500" />
            </label>
            <label className="flex items-center justify-between">
              <span className="text-sm font-bold text-slate-300">Bahasa suara TTS</span>
              <select value={state.settings.ttsVoice} onChange={(e) => socket.emit('settings:update', { ttsVoice: e.target.value as any })}
                className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5">
                <option value="id">Indonesia</option><option value="ar">Arab</option><option value="off">Nonaktif</option>
              </select>
            </label>
            <hr className="border-slate-800" />
            <Btn onClick={() => confirm('RESET TOTAL permainan? (skor, soal terpakai, log)') && socket.emit('game:reset')} icon={Trash2} label="Reset Total Permainan" color="bg-rose-800" />
          </div>
        )}

        {/* ================= TAB LOG ================= */}
        {tab === 'log' && (
          <div className="max-w-3xl mx-auto bg-slate-900 border border-slate-800 rounded-2xl p-4">
            <h2 className="font-black text-lg mb-3 flex items-center gap-2"><MessageSquare size={18} /> Audit Log Juri</h2>
            <ul className="space-y-1 text-sm font-mono max-h-[70vh] overflow-y-auto">
              {state.log.map((l, i) => (
                <li key={i} className="flex gap-3 border-b border-slate-800/60 pb-1">
                  <span className="text-slate-500 shrink-0">{new Date(l.at).toLocaleTimeString('id-ID')}</span>
                  <span className={l.actor === 'system' ? 'text-sky-400' : 'text-slate-200'}>{l.message}</span>
                </li>
              ))}
              {!state.log.length && <li className="text-slate-500">Belum ada aktivitas.</li>}
            </ul>
          </div>
        )}
      </main>

      <footer className="text-center text-[11px] text-slate-600 py-2 border-t border-slate-900">
        Pintasan: [Spasi] timer · [J] jawaban · [N] selesai · [R] reset timer · [C] clue · [1–9] tambah poin regu sesuai urutan
      </footer>
    </div>
  );

  // ------- closure helpers (memakai `state` di atas) -------
  function applyExpr(groupId: string, negate = false) {
    const raw = expr[groupId] ?? '';
    const base = raw.trim() ? raw : String(q?.points ?? 10);
    let val: number | null = /^[\d\s+\-*/().]+$/.test(base) && /[^\d]/.test(base)
      ? tryEval(base) : Number(base);
    if (val == null || !isFinite(val) || val === 0) return;
    socket.emit('group:score', groupId, negate ? -Math.abs(val) : val);
    sounds.playCorrect();
    setExpr((p) => ({ ...p, [groupId]: '' }));
  }

  function AddGroupForm() {
    const [name, setName] = useState('');
    return (
      <div className="flex gap-2">
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nama regu (mis. Al-Fatih)"
          onKeyDown={(e) => { if (e.key === 'Enter' && name.trim()) { socket.emit('group:add', name); setName(''); } }}
          className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-4 py-2.5" />
        <button onClick={() => { if (name.trim()) { socket.emit('group:add', name); setName(''); } }}
          className="px-5 rounded-xl bg-emerald-600 font-black cursor-pointer">+ Tambah</button>
      </div>
    );
  }

  function QuestionEditor({ draft, setDraft, onClose }: { draft: Question; setDraft: (q: Question) => void; onClose: () => void }) {
    const upd = (patch: Partial<Question>) => setDraft({ ...draft, ...patch });
    return (
      <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4" onClick={onClose}>
        <div className="bg-slate-900 border border-slate-700 rounded-2xl p-5 w-full max-w-2xl max-h-[90vh] overflow-y-auto space-y-3" onClick={(e) => e.stopPropagation()}>
          <h3 className="font-black text-lg">{st.questions.some((x) => x.id === draft.id) ? '✏️ Sunting Soal' : '➕ Soal Baru'}</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
            <Field label="Tipe"><select value={draft.type} onChange={(e) => upd({ type: e.target.value as QuestionType })} className="sel">
              {(Object.keys(TYPE_LABEL) as QuestionType[]).map((t) => <option key={t} value={t}>{TYPE_LABEL[t]}</option>)}
            </select></Field>
            <Field label="Amplop"><input value={draft.packet ?? ''} onChange={(e) => upd({ packet: e.target.value })} placeholder="Amplop A" className="inp" /></Field>
            <Field label="Kategori"><input value={draft.category} onChange={(e) => upd({ category: e.target.value })} className="inp" /></Field>
            <Field label="Poin"><input type="number" value={draft.points} onChange={(e) => upd({ points: Number(e.target.value) || 0 })} className="inp" /></Field>
          </div>
          <Field label="Soal"><textarea value={draft.text} onChange={(e) => upd({ text: e.target.value })} rows={3} className="inp" /></Field>
          <Field label="Jawaban"><input value={draft.answer} onChange={(e) => upd({ answer: e.target.value })} className="inp" /></Field>
          {draft.type === 'pilihan_ganda' && (
            <Field label="Pilihan (pisahkan baris baru)">
              <textarea rows={4} defaultValue={(draft.options ?? []).join('\n')} onBlur={(e) => upd({ options: e.target.value.split('\n').filter(Boolean) })} className="inp" />
            </Field>
          )}
          {draft.type === 'clue' && (
            <Field label="Clue bertingkat (baris baru = tahap berikutnya)">
              <textarea rows={4} defaultValue={(draft.clues ?? []).join('\n')} onBlur={(e) => upd({ clues: e.target.value.split('\n').filter(Boolean) })} className="inp" />
            </Field>
          )}
          {draft.type === 'audio' && <Field label="File audio (nama file di ./media/ atau URL)"><input value={draft.audioUrl ?? ''} onChange={(e) => upd({ audioUrl: e.target.value })} placeholder="qiroah-yusuf.mp3" className="inp" /></Field>}
          {(draft.type === 'gambar') && (
            <>
              <Field label="Gambar soal (nama file di ./media/ atau URL)"><input value={draft.questionImage ?? ''} onChange={(e) => upd({ questionImage: e.target.value })} placeholder="kabah.jpg" className="inp" /></Field>
              <Field label="Gambar pembahasan (opsional)"><input value={draft.answerImage ?? ''} onChange={(e) => upd({ answerImage: e.target.value })} className="inp" /></Field>
            </>
          )}
          <div className="flex gap-2 justify-end pt-2">
            <button onClick={onClose} className="px-4 py-2 rounded-xl bg-slate-800 font-bold cursor-pointer">Batal</button>
            <button onClick={() => { socket.emit('question:upsert', draft); onClose(); }} className="px-5 py-2 rounded-xl bg-emerald-600 font-black cursor-pointer">Simpan</button>
          </div>
          <style>{`.inp{width:100%;background:#1e293b;border:1px solid #334155;border-radius:10px;padding:8px 12px;color:#fff;outline:none}.inp:focus{border-color:#34d399}.sel{width:100%;background:#1e293b;border:1px solid #334155;border-radius:10px;padding:8px 12px;color:#fff}`}</style>
        </div>
      </div>
    );
  }

  function Field({ label, children }: { label: string; children: React.ReactNode }) {
    return <label className="block text-xs font-black uppercase text-slate-400 space-y-1"><span>{label}</span><div className="normal-case">{children}</div></label>;
  }

  function exportResults() {
    const rows = [...st.groups].sort((a, b) => b.score - a.score).map((g, i) => ({ Peringkat: i + 1, Regu: g.name, Poin: g.score }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Hasil');
    XLSX.writeFile(wb, `hasil-ccs-${st.roomId}-${new Date().toISOString().slice(0, 10)}.xlsx`);
  }

  function exportQuestions() {
    const blob = new Blob([JSON.stringify(st.questions, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `bank-soal-${st.roomId}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  }

  function onImportFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        let list: any[] = [];
        if (f.name.endsWith('.json')) list = JSON.parse(String(reader.result));
        else {
          const wb = XLSX.read(reader.result as ArrayBuffer, { type: 'array' });
          list = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]);
        }
        const qs: Question[] = list.map((r, i) => normRow(r, i));
        if (qs.length) { socket.emit('questions:replaceAll', qs); alert(`${qs.length} soal berhasil dimuat.`); }
      } catch (err) { alert('Format tidak dikenali: ' + (err as Error).message); }
    };
    reader.readAsArrayBuffer(f);
    e.target.value = '';
  }
}

// ---------------- util luar komponen ----------------
function normRow(r: any, i: number): Question {
  const str = (v: any) => String(v ?? '').trim();
  const list = (v: any) => Array.isArray(v) ? v.map(String) : str(v).split(/[|;\n]/).map((s) => s.trim()).filter(Boolean);
  const type = (str(r.type ?? r.Tipe) || 'wajib') as QuestionType;
  return {
    id: str(r.id) || `q-${Date.now()}-${i}`,
    type,
    text: str(r.text ?? r.Soal ?? r.teks),
    answer: str(r.answer ?? r.Jawaban),
    category: str(r.category ?? r.Kategori) || 'Umum',
    points: Number(r.points ?? r.Poin ?? (type === 'rebutan' ? 30 : 20)) || 20,
    packet: str(r.packet ?? r.Amplop) || undefined,
    options: list(r.options ?? r.Pilihan).length ? list(r.options ?? r.Pilihan) : undefined,
    clues: list(r.clues ?? r.Clue).length ? list(r.clues ?? r.Clue) : undefined,
    audioUrl: str(r.audioUrl ?? r.Audio) || undefined,
    questionImage: str(r.questionImage ?? r.Gambar) || undefined,
    answerImage: str(r.answerImage ?? r.GambarJawaban) || undefined,
  };
}

function blankQuestion(): Question {
  return { id: `q-${Date.now()}`, type: 'wajib', text: '', answer: '', category: 'Umum', points: 20, packet: 'Amplop A' };
}

function tryEval(expr: string): number | null {
  const c = expr.replace(/\s+/g, '');
  if (!/^[\d+\-*/().]+$/.test(c)) return null;
  try { const v = Function(`"use strict";return(${c})`)(); return typeof v === 'number' && isFinite(v) ? Math.round(v) : null; } catch { return null; }
}

function Btn({ onClick, icon: Icon, label, color }: { onClick: () => void; icon: any; label: string; color: string }) {
  return (
    <button onClick={onClick} className={cn('flex items-center gap-2 px-4 py-2 rounded-xl font-black text-sm text-white hover:brightness-110 active:scale-95 transition cursor-pointer', color)}>
      <Icon size={16} /> {label}
    </button>
  );
}
