import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useGameState, setSocketRole } from '../lib/useGameState';
import { socket } from '../lib/socket';
import { sounds } from '../lib/audio';
import { cn } from '../lib/utils';

/**
 * BEL DARURAT via HP/tablet (opsional). Peserta TIDAK wajib pakai HP:
 * ini hanya cadangan bila keypad USB bermasalah. Tetap 100% LAN/offline.
 */
export default function BuzzerRemote() {
  const { roomId = 'lomba' } = useParams();
  setSocketRole('stage'); // role non-admin; cukup utk mengirim buzz
  const { state, connected } = useGameState(roomId);
  const [picked, setPicked] = useState<string | null>(null);

  if (!state) return <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center">Menghubungkan…</div>;

  const myGroup = state.groups.find((g) => g.id === picked);
  const iBuzzedFirst = state.buzzedGroupId === picked && !!picked;

  const press = () => {
    if (!picked || !state.buzzerEnabled) return;
    socket.emit('buzz', picked);
    sounds.playBuzzer(); // getar balik utk operator bel
    if (navigator.vibrate) navigator.vibrate(120);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 to-rose-950/40 text-white p-6 flex flex-col max-w-md mx-auto" onClick={() => sounds.unlock()}>
      <h1 className="font-black text-xl mb-1">🔔 Bel Darurat — {state.roomId}</h1>
      <p className={cn('text-xs font-bold mb-4', connected ? 'text-emerald-400' : 'text-red-400')}>
        {connected ? 'Terhubung ke server lomba' : 'Terputus dari server!'}
      </p>

      <label className="text-xs uppercase font-black text-slate-400 mb-1 block">Regu HP ini mewakili:</label>
      <select value={picked ?? ''} onChange={(e) => setPicked(e.target.value || null)}
        className="w-full bg-slate-800 border border-slate-600 rounded-xl px-4 py-3 mb-6 text-lg">
        <option value="">— pilih regu —</option>
        {state.groups.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
      </select>

      <button
        onPointerDown={press}
        disabled={!picked || !state.buzzerEnabled}
        className={cn(
          'flex-1 min-h-[40vh] rounded-[2.5rem] border-4 font-black text-3xl transition select-none touch-manipulation',
          !picked ? 'bg-slate-800 border-slate-700 text-slate-600'
            : !state.buzzerEnabled ? 'bg-slate-800 border-slate-600 text-slate-500'
            : iBuzzedFirst ? 'bg-emerald-500 border-emerald-300 text-slate-950 pulse-ring'
            : 'bg-rose-600 border-rose-400 active:scale-95 shadow-2xl',
        )}
      >
        {!picked ? 'Pilih Regu Dulu'
          : !state.buzzerEnabled ? '⏸ BEL SEDANG DITUTUP JURI'
          : iBuzzedFirst ? `✅ ${myGroup?.name}\nPALING CEPAT!`
          : `TEKAN!\n${myGroup?.name}`}
      </button>

      <p className="text-center text-xs text-slate-500 mt-4">
        Fase: <b>{state.gamePhase}</b> · Bel aktif hanya saat soal rebutan/bonus.
      </p>
    </div>
  );
}
