import { useEffect, useState } from 'react';
import { socket } from '../lib/socket';
import { GameState } from '../types';

/**
 * Hook pusat state game. SELALU melepas listener saat unmount
 * (memperbaiki bug kebocoran listener pada versi lama).
 */
export function useGameState(roomId: string) {
  const [state, setState] = useState<GameState | null>(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    const onState = (s: GameState) => setState(s);
    const onConnect = () => {
      setConnected(true);
      socket.emit('joinRoom', roomId, (navigator as any).__role ?? 'stage');
    };
    const onDisconnect = () => setConnected(false);

    socket.on('gameState', onState);
    socket.on('connect', onConnect);
    socket.on('disconnect', onDisconnect);

    if (socket.connected) onConnect();

    return () => {
      socket.off('gameState', onState);
      socket.off('connect', onConnect);
      socket.off('disconnect', onDisconnect);
    };
  }, [roomId]);

  return { state, connected };
}

/** Simpan role device ini (admin/stage) supaya dikirim saat join ulang/reconnect. */
export function setSocketRole(role: 'admin' | 'stage') {
  (navigator as any).__role = role;
}
