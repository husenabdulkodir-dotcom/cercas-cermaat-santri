// ============================================================================
// SoundEffects — Web Audio API, 100% offline (tanpa file audio & internet)
// + Text-to-Speech memakai suara bawaan OS (Web Speech API).
// ============================================================================

class SoundEffects {
  private ctx: AudioContext | null = null;
  private lastSpeakAt = 0;

  private init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      this.ctx = new AudioCtx();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  /** Panggil dari event klik pertama user utk membuka kunci autoplay browser. */
  unlock() {
    this.init();
    if (this.ctx?.state === 'running') {
      // beep senyap singkat sebagai konfirmasi konteks aktif
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      g.gain.value = 0.0001;
      o.connect(g); g.connect(this.ctx.destination);
      o.start(); o.stop(this.ctx.currentTime + 0.02);
    }
  }

  get ready() { return this.ctx?.state === 'running'; }

  // ---------- Efek bel / buzzer ----------
  playBuzzer() {
    this.init();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(520, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(880, this.ctx.currentTime + 0.12);
    gain.gain.setValueAtTime(0.35, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.35);
    osc.connect(gain); gain.connect(this.ctx.destination);
    osc.start(); osc.stop(this.ctx.currentTime + 0.35);
  }

  playCorrect() {
    this.init();
    if (!this.ctx) return;
    [523.25, 659.25, 783.99, 1046.5].forEach((freq, i) => {
      const t = this.ctx!.currentTime + i * 0.09;
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0, t);
      gain.gain.linearRampToValueAtTime(0.28, t + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
      osc.connect(gain); gain.connect(this.ctx!.destination);
      osc.start(t); osc.stop(t + 0.4);
    });
  }

  playWrong() {
    this.init();
    if (!this.ctx) return;
    [220, 164.81].forEach((freq, i) => {
      const t = this.ctx!.currentTime + i * 0.2;
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0.25, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.3);
      osc.connect(gain); gain.connect(this.ctx!.destination);
      osc.start(t); osc.stop(t + 0.35);
    });
  }

  playTick() {
    this.init();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(880, this.ctx.currentTime);
    gain.gain.setValueAtTime(0.12, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.06);
    osc.connect(gain); gain.connect(this.ctx.destination);
    osc.start(); osc.stop(this.ctx.currentTime + 0.07);
  }

  playTimesUp() {
    this.init();
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(140, t);
    osc.frequency.exponentialRampToValueAtTime(60, t + 1.3);
    gain.gain.setValueAtTime(0.45, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 1.3);
    osc.connect(gain); gain.connect(this.ctx.destination);
    osc.start(t); osc.stop(t + 1.35);
  }

  /** SFX pendek utk pembukaan amplop (whoosh naik). */
  playEnvelope() {
    this.init();
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(200, t);
    osc.frequency.exponentialRampToValueAtTime(900, t + 0.4);
    gain.gain.setValueAtTime(0.2, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.5);
    osc.connect(gain); gain.connect(this.ctx.destination);
    osc.start(t); osc.stop(t + 0.5);
  }

  // ---------- TTS: bacakan soal / hitungan mundur ----------
  private pickVoice(lang: string): SpeechSynthesisVoice | null {
    const voices = window.speechSynthesis?.getVoices?.() ?? [];
    return voices.find((v) => v.lang?.toLowerCase().startsWith(lang)) ?? null;
  }

  speak(text: string, opts: { lang?: 'id' | 'ar'; rate?: number; interrupt?: boolean } = {}) {
    if (!('speechSynthesis' in window) || !text) return;
    if (opts.interrupt !== false) window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = opts.lang === 'ar' ? 'ar-SA' : 'id-ID';
    const v = this.pickVoice(opts.lang === 'ar' ? 'ar' : 'id');
    if (v) u.voice = v;
    u.rate = opts.rate ?? 1;
    u.pitch = 1;
    u.volume = 1;
    window.speechSynthesis.speak(u);
  }

  /**
   * Hitungan mundur bersuara: ucapkan angka hanya bila jeda cukup antar-detik
   * (anti-tumpuk). Panggil setiap detik dari stage.
   */
  speakCountdownNumber(n: number, lang: 'id' | 'ar' = 'id') {
    if ((lang as string) === 'off') return;
    const now = Date.now();
    if (now - this.lastSpeakAt < 850) return; // anti-overlap
    this.lastSpeakAt = now;
    if (!('speechSynthesis' in window)) return;
    const u = new SpeechSynthesisUtterance(String(n));
    u.lang = lang === 'ar' ? 'ar-SA' : 'id-ID';
    const v = this.pickVoice(lang === 'ar' ? 'ar' : 'id');
    if (v) u.voice = v;
    u.rate = 1.15;
    u.volume = 1;
    window.speechSynthesis.speak(u);
  }

  stopSpeaking() {
    if ('speechSynthesis' in window) window.speechSynthesis.cancel();
  }
}

export const sounds = new SoundEffects();
