import { io, Socket } from 'socket.io-client';

// Mode offline/LAN: server socket selalu di port 4600 pada host yang sama.
// - dev  : UI di :4601 (vite), socket ke :4600
// - prod : UI & socket sama di :4600
const SOCKET_PORT = 4600;
const proto = window.location.protocol === 'https:' ? 'wss' : 'ws';
const host = window.location.hostname || 'localhost';
const url = `${proto}://${host}:${SOCKET_PORT}`;

export const socket: Socket = io(url, {
  autoConnect: true,
  reconnection: true,
  reconnectionAttempts: Infinity,
  reconnectionDelay: 500,
  timeout: 8000,
});
