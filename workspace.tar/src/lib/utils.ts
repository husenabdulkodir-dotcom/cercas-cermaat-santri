import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

/** Gabung class Tailwind tanpa konflik. */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Normalisasi path aset (gambar/audio soal).
 * Menerima: URL http(s) (dilewati), base64 data-URI (dilewati),
 * atau relatif folder ./media/ di root proyek (untuk bank soal offline).
 */
export function resolveAsset(src?: string): string | undefined {
  if (!src) return undefined;
  const s = src.trim();
  if (!s) return undefined;
  if (/^(https?:|data:|blob:|\/)/i.test(s)) return s;
  return `/media/${s.replace(/^\.?\/?(media\/)?/i, '')}`;
}

export function fmtTime(sec: number): string {
  const m = Math.floor(Math.max(0, sec) / 60);
  const r = Math.max(0, sec) % 60;
  return `${m}:${r.toString().padStart(2, '0')}`;
}

export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
