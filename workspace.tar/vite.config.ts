import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

// UI dibangun oleh Vite (dev: :4601, prod: dist/ yang disajikan server.ts di :4600)
// Socket.IO & API selalu di :4600 — client connect eksplisit ke port tersebut.
export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    host: true, // penting: agar bisa diakses device lain via LAN pondok
    port: 4601,
  },
  build: { outDir: 'dist' },
});
