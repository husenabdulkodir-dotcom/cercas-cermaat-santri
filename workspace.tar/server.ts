// ============================================================================
// Cerdas Cermat Santri — Server (Express + Socket.IO)
// Arsitektur multi-device untuk lomba OFFLINE:
//   - 1 laptop ADMIN JURI (buka soal, nilai, timer)  -> /admin/:roomId
//   - 1 laptop PROYEKTOR  (layar besar penonton)      -> /stage/:roomId
//   - keduanya cukup colok LAN / WiFi router yang sama (tanpa internet).
// Semua state disimpan di server + snapshot JSON (crash-safe).
// ============================================================================
import express from 'express';
import http from 'http';
import os from 'os';
import fs from 'fs';
import path from 'path';
import { Server as SocketIOServer } from 'socket.io';

const PORT = Number(process.env.PORT || 4600);
const SNAPSHOT_DIR = path.resolve(process.cwd(), 'data');
const SNAPSHOT_FILE = path.join(SNAPSHOT_DIR, 'game-snapshot.json');

// ---------------------------------------------------------------------------
// Tipe data (selaras dengan src/types.ts di sisi client)
// ---------------------------------------------------------------------------
export interface Group {
  id: string;        // kode tombol fisik, mis. "regu-1" atau slug nama "fatih"
  name: string;
  score: number;
}

export type QuestionType =
  | 'wajib' | 'lempar' | 'rebutan'
  | 'pilihan_ganda' | 'clue' | 'audio' | 'gambar';

export interface Question {
  id: string;
  text: string;
  answer: string;
  type: QuestionType;
  category: string;
  points: number;
  packet?: string;
  options?: string[];
  clues?: string[];
  audioUrl?: string;
  questionImage?: string;
  answerImage?: string;
}

export type GamePhase =
  | 'Persiapan' | 'Soal Wajib' | 'Soal Lempar' | 'Soal Rebutan'
  | 'Soal Bonus' | 'Pengumuman';

export interface BuzzerEvent {
  groupId: string;
  at: number;       // timestamp server (ms) — penentu siapa paling cepat
}

export interface LogEntry {
  at: number;
  actor: 'admin' | 'system';
  message: string;
}

export interface GameState {
  roomId: string;
  groups: Group[];
  questions: Question[];
  activeQuestion: Question | null;
  gamePhase: GamePhase;

  // Timer (dihitung dari deadline epoch-ms supaya sinkron antar device)
  timerDurationSec: number;
  timerEndsAt: number | null;   // null = belum jalan / sudah berhenti
  isTimerRunning: boolean;
  timeLeftOverride: number | null; // dipakai utk pause & hasil time-up

  buzzerEnabled: boolean;
  buzzQueue: BuzzerEvent[];     // urutan presisi berdasarkan waktu server
  buzzedGroupId: string | null; // = buzzQueue[0].groupId (praktis utk UI)

  revealAnswer: boolean;
  openedEnvelope: string | null;
  usedQuestionIds: string[];
  activeTurnGroupId: string | null;
  passedGroupIds: string[];
  activeClueIndex: number;
  spinWheelResult: string | null;
  groupBets: Record<string, number>;

  settings: {
    wajibSec: number;
    lemparSec: number;
    rebutanSec: number;
    bonusSec: number;
    penaltyLempar: number;   // pengurangan poin jika regu penerima gagal
    speakCountdown: boolean; // bunyikan hitungan suara
    ttsVoice: 'id' | 'ar' | 'off';
  };

  log: LogEntry[];
  updatedAt: number;
}

// ---------------------------------------------------------------------------
// State awal + persistensi snapshot
// ---------------------------------------------------------------------------
const DEFAULT_SETTINGS: GameState['settings'] = {
  wajibSec: 30,
  lemparSec: 20,
  rebutanSec: 15,
  bonusSec: 60,
  penaltyLempar: 10,
  speakCountdown: true,
  ttsVoice: 'id',
};

function makeInitialState(roomId: string): GameState {
  return {
    roomId,
    groups: [],
    questions: [],
    activeQuestion: null,
    gamePhase: 'Persiapan',
    timerDurationSec: 30,
    timerEndsAt: null,
    isTimerRunning: false,
    timeLeftOverride: null,
    buzzerEnabled: false,
    buzzQueue: [],
    buzzedGroupId: null,
    revealAnswer: false,
    openedEnvelope: null,
    usedQuestionIds: [],
    activeTurnGroupId: null,
    passedGroupIds: [],
    activeClueIndex: 0,
    spinWheelResult: null,
    groupBets: {},
    settings: { ...DEFAULT_SETTINGS },
    log: [],
    updatedAt: Date.now(),
  };
}

const rooms = new Map<string, GameState>();

function getRoom(roomId: string): GameState {
  let s = rooms.get(roomId);
  if (!s) {
    s = loadSnapshot(roomId) ?? makeInitialState(roomId);
    rooms.set(roomId, s);
  }
  return s;
}

function saveSnapshot(state: GameState) {
  try {
    if (!fs.existsSync(SNAPSHOT_DIR)) fs.mkdirSync(SNAPSHOT_DIR, { recursive: true });
    fs.writeFileSync(SNAPSHOT_FILE, JSON.stringify({ [state.roomId]: state }, null, 2));
  } catch (e) {
    console.error('Gagal simpan snapshot:', e);
  }
}

function loadSnapshot(roomId: string): GameState | null {
  try {
    if (!fs.existsSync(SNAPSHOT_FILE)) return null;
    const all = JSON.parse(fs.readFileSync(SNAPSHOT_FILE, 'utf8'));
    const raw = all?.[roomId];
    if (!raw) return null;
    const base = makeInitialState(roomId);
    const merged: GameState = { ...base, ...raw, settings: { ...base.settings, ...(raw.settings ?? {}) } };
    // Setelah restart server, timer dianggap PAUSE (aman utk juri)
    merged.isTimerRunning = false;
    merged.timerEndsAt = null;
    merged.timeLeftOverride = remainingMs(merged) > 0 ? Math.round(remainingMs(merged) / 1000) : merged.timeLeftOverride;
    return merged;
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// Helper
// ---------------------------------------------------------------------------
function remainingMs(s: GameState): number {
  if (s.isTimerRunning && s.timerEndsAt) return Math.max(0, s.timerEndsAt - Date.now());
  if (s.timeLeftOverride != null) return s.timeLeftOverride * 1000;
  return s.timerDurationSec * 1000;
}

function pushLog(s: GameState, message: string, actor: LogEntry['actor'] = 'admin') {
  s.log.unshift({ at: Date.now(), actor, message });
  s.log = s.log.slice(0, 200);
}

function sanitizeRoomId(raw: unknown): string {
  const v = String(raw ?? 'lomba').trim().toLowerCase().replace(/[^a-z0-9-]/g, '-').slice(0, 24);
  return v || 'lomba';
}

/** Kode tombol singkat & unik dari nama regu (untuk keypad fisik/USB). */
export function groupKeyFromName(name: string, existing: Group[]): string {
  const skip = new Set(['al', 'el', 'ad', 'as', 'az', 'bin', 'binti', 'bn', 'ibnu', 'ibn', 'abu', 'ra', 'umm', 'rodhiyallahu', 'radhiyallahu']);
  const words = name.split(/[^a-zA-Z0-9]+/).filter(Boolean);
  const core = words.filter((w) => !skip.has(w.toLowerCase()));
  let base = ((core.length ? core : words).slice(0, 2).join('') || 'regu').toLowerCase().slice(0, 10);
  let key = base, n = 2;
  while (existing.some((g) => g.id === key)) key = `${base}${n++}`;
  return key;
}

// ---------------------------------------------------------------------------
// Ekspresi aman utk kalkulator skor juri (WHITELIST karakter saja)
// Mengizinkan: angka, + - * / ( ) . spasi. Evaluasi via Function (sandboxed-ish).
// ---------------------------------------------------------------------------
function safeEval(expr: string): number | null {
  const cleaned = expr.replace(/\s+/g, '');
  if (!/^[\d+\-*/().]+$/.test(cleaned) || cleaned.length === 0) return null;
  try {
    // eslint-disable-next-line no-new-func
    const val = Function(`"use strict"; return (${cleaned});`)();
    if (typeof val === 'number' && isFinite(val)) return Math.round(val);
    return null;
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// Express + Vite dev/prod
// ---------------------------------------------------------------------------
const app = express();
const server = http.createServer(app);
const io = new SocketIOServer(server, {
  cors: { origin: true },
  pingInterval: 5000,
  pingTimeout: 20000, // toleran utk WiFi pondok yang lemah
});

app.get('/api/ip', (_req, res) => {
  const nets = os.networkInterfaces();
  const ips: string[] = [];
  for (const list of Object.values(nets)) {
    for (const n of list ?? []) {
      if (n.family === 'IPv4' && !n.internal) ips.push(n.address);
    }
  }
  res.json({ ips, port: PORT });
});

// Snapshot cadangan utk di-restore manual bila perlu
app.get('/api/snapshot/:roomId', (req, res) => {
  res.json(getRoom(sanitizeRoomId(req.params.roomId)));
});

const isProd = process.env.NODE_ENV === 'production';
if (isProd) {
  app.use(express.static(path.resolve(process.cwd(), 'dist')));
  // Folder ./media utk gambar & audio bank soal (offline)
  app.use('/media', express.static(path.resolve(process.cwd(), 'media')));
  app.get('*', (_req, res) => res.sendFile(path.resolve(process.cwd(), 'dist/index.html')));
} else {
  (async () => {
    const vitePort = PORT + 1;
    const { createServer: createVite } = await import('vite');
    const vite = await createVite({
      configFile: path.resolve('vite.config.ts'),
      server: { port: vitePort, host: true },
      appType: 'spa',
    });
    await vite.listen();
    console.log(`Vite dev UI : http://localhost:${vitePort}`);
    console.log(`Socket/API  : ws://localhost:${PORT}  (client otomatis connect ke sini)`);
  })().catch((e) => {
    console.error('Vite dev gagal start:', e?.message ?? e);
  });
}

// ---------------------------------------------------------------------------
// Socket.IO
// ---------------------------------------------------------------------------
io.on('connection', (socket) => {
  let joinedRoom: string | null = null;

  socket.on('joinRoom', (rawRoomId: string, role: 'admin' | 'stage' = 'stage') => {
    joinedRoom = sanitizeRoomId(rawRoomId);
    socket.join(joinedRoom);
    const state = getRoom(joinedRoom);
    pushLog(state, `${role.toUpperCase()} terhubung`, 'system');
    socket.emit('gameState', publicState(state));
    broadcast(joinedRoom);
  });

  socket.on('requestGameState', () => {
    if (joinedRoom) socket.emit('gameState', publicState(getRoom(joinedRoom)));
  });

  // ---------------- Regu ----------------
  socket.on('group:add', (name: string) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    const clean = String(name ?? '').trim().slice(0, 40);
    if (!clean) return;
    const g: Group = { id: groupKeyFromName(clean, s.groups), name: clean, score: 0 };
    s.groups.push(g);
    pushLog(s, `Regu ditambahkan: ${g.name} (kode: ${g.id})`);
    touch(s);
  });

  socket.on('group:rename', (id: string, name: string) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    const g = s.groups.find((x) => x.id === id);
    if (!g) return;
    g.name = String(name ?? g.name).trim().slice(0, 40) || g.name;
    touch(s);
  });

  socket.on('group:remove', (id: string) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    const g = s.groups.find((x) => x.id === id);
    s.groups = s.groups.filter((x) => x.id !== id);
    if (s.activeTurnGroupId === id) s.activeTurnGroupId = null;
    if (s.buzzedGroupId === id) { s.buzzedGroupId = null; s.buzzQueue = []; }
    if (g) pushLog(s, `Regu dihapus: ${g.name}`);
    touch(s);
  });

  socket.on('group:score', (id: string, deltaOrExpr: number | string) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    const g = s.groups.find((x) => x.id === id);
    if (!g) return;
    let delta: number | null = null;
    if (typeof deltaOrExpr === 'number') delta = deltaOrExpr;
    else if (typeof deltaOrExpr === 'string') delta = safeEval(deltaOrExpr);
    if (delta == null || delta === 0) return;
    g.score += delta;
    pushLog(s, `${g.name}: ${delta > 0 ? '+' : ''}${delta} → ${g.score}`);
    touch(s);
  });

  socket.on('group:setScore', (id: string, value: number) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    const g = s.groups.find((x) => x.id === id);
    if (!g) return;
    const v = Math.round(Number(value));
    if (!isFinite(v)) return;
    pushLog(s, `${g.name} skor diatur: ${g.score} → ${v}`);
    g.score = v;
    touch(s);
  });

  socket.on('groups:resetScores', () => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    s.groups.forEach((g) => (g.score = 0));
    pushLog(s, 'SKOR SEMUA REGU DIRESET');
    touch(s);
  });

  // ---------------- Bank soal ----------------
  socket.on('questions:replaceAll', (list: Question[]) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    s.questions = Array.isArray(list) ? list : [];
    s.usedQuestionIds = s.usedQuestionIds.filter((id) => s.questions.some((q) => q.id === id));
    pushLog(s, `Bank soal dimuat: ${s.questions.length} butir`);
    touch(s);
  });

  socket.on('question:upsert', (q: Question) => {
    if (!joinedRoom || !q?.id) return;
    const s = getRoom(joinedRoom);
    const i = s.questions.findIndex((x) => x.id === q.id);
    if (i >= 0) s.questions[i] = q; else s.questions.push(q);
    touch(s);
  });

  socket.on('question:delete', (id: string) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    s.questions = s.questions.filter((q) => q.id !== id);
    s.usedQuestionIds = s.usedQuestionIds.filter((x) => x !== id);
    if (s.activeQuestion?.id === id) { s.activeQuestion = null; s.revealAnswer = false; }
    touch(s);
  });

  // ---------------- Alur permainan ----------------
  socket.on('phase:set', (phase: GamePhase) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    if (!['Persiapan', 'Soal Wajib', 'Soal Lempar', 'Soal Rebutan', 'Soal Bonus', 'Pengumuman'].includes(phase)) return;
    s.gamePhase = phase;
    stopTimer(s, `Fase → ${phase}`);
    touch(s);
  });

  socket.on('envelope:open', (packet: string) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    s.openedEnvelope = String(packet ?? '').slice(0, 40);
    pushLog(s, `Amplop dibuka: ${s.openedEnvelope}`);
    touch(s);
  });

  socket.on('question:start', (id: string) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    const q = s.questions.find((x) => x.id === id);
    if (!q) return;
    s.activeQuestion = q;
    s.revealAnswer = false;
    s.activeClueIndex = 0;
    s.buzzQueue = [];
    s.buzzedGroupId = null;
    s.passedGroupIds = [];
    s.usedQuestionIds = [...new Set([...s.usedQuestionIds, q.id])];
    const dur = q.type === 'wajib' ? s.settings.wajibSec
      : q.type === 'lempar' ? s.settings.lemparSec
      : q.type === 'rebutan' ? s.settings.rebutanSec
      : s.settings.bonusSec;
    s.timerDurationSec = dur;
    s.timeLeftOverride = dur;
    s.buzzerEnabled = q.type === 'rebutan' || q.type === 'audio' || q.type === 'gambar' || q.type === 'pilihan_ganda';
    pushLog(s, `Soal dimulai [${q.type}] (${dur}s): ${q.text.slice(0, 60)}`);
    touch(s);
  });

  socket.on('question:finish', () => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    stopTimer(s, null);
    s.buzzerEnabled = false;
    touch(s);
  });

  socket.on('answer:reveal', (show: boolean) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    s.revealAnswer = !!show;
    if (show && s.activeQuestion) pushLog(s, `Jawaban ditampilkan: ${s.activeQuestion.answer.slice(0, 60)}`);
    touch(s);
  });

  socket.on('clue:next', () => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    const max = (s.activeQuestion?.clues?.length ?? 1) - 1;
    s.activeClueIndex = Math.min(max, s.activeClueIndex + 1);
    touch(s);
  });

  socket.on('turn:set', (groupId: string | null) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    s.activeTurnGroupId = groupId && s.groups.some((g) => g.id === groupId) ? groupId : null;
    if (groupId) { s.buzzQueue = []; s.buzzedGroupId = groupId; }
    touch(s);
  });

  socket.on('turn:pass', (groupId: string) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    if (!s.groups.some((g) => g.id === groupId)) return;
    if (!s.passedGroupIds.includes(groupId)) s.passedGroupIds.push(groupId);
    // Lemparan ke regu berikutnya (rotasi melingkari daftar)
    const idx = s.groups.findIndex((g) => g.id === groupId);
    let next: Group | undefined;
    for (let step = 1; step <= s.groups.length; step++) {
      const cand = s.groups[(idx + step) % s.groups.length];
      if (cand && !s.passedGroupIds.includes(cand.id)) { next = cand; break; }
    }
    if (next) {
      s.activeTurnGroupId = next.id;
      s.buzzedGroupId = next.id;
      pushLog(s, `Soal dilempar ke: ${next.name} (penalti ${s.settings.penaltyLempar} utk ${s.groups[idx]?.name ?? '-'})`);
    } else {
      s.activeTurnGroupId = null;
      s.buzzedGroupId = null;
      pushLog(s, 'Semua regu sudah menerima lemparan — soal dianggap lewat');
    }
    touch(s);
  });

  socket.on('lempar:failed', (groupId: string) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    const g = s.groups.find((x) => x.id === groupId);
    if (!g) return;
    g.score -= s.settings.penaltyLempar;
    pushLog(s, `${g.name} GAGAL menjawab lemparan: -${s.settings.penaltyLempar} → ${g.score}`);
    touch(s);
  });

  // ---------------- Buzzer (bisa dari HP/tablet ORANGE sebagai bel cadangan) --
  socket.on('buzz', (groupId: string) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    if (!s.buzzerEnabled) return;
    if (!s.groups.some((g) => g.id === groupId)) return;
    if (s.buzzQueue.some((b) => b.groupId === groupId)) return; // 1× per regu per soal
    const ev: BuzzerEvent = { groupId, at: Date.now() };
    s.buzzQueue.push(ev);
    s.buzzQueue.sort((a, b) => a.at - b.at);
    s.buzzedGroupId = s.buzzQueue[0].groupId;
    pushLog(s, `BEL: ${s.groups.find((g) => g.id === groupId)?.name ?? groupId} @ ${new Date(ev.at).toLocaleTimeString('id-ID')}`);
    touch(s);
    io.to(joinedRoom).emit('buzz-event', ev); // utk animasi+suara stage
  });

  socket.on('buzzer:clear', () => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    s.buzzQueue = [];
    s.buzzedGroupId = null;
    touch(s);
  });

  socket.on('buzzer:toggle', (enabled: boolean) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    s.buzzerEnabled = !!enabled;
    pushLog(s, `Bel ${s.buzzerEnabled ? 'DIBUKA' : 'DIKUNCI'} manual`);
    touch(s);
  });

  // ---------------- Timer ----------------
  socket.on('timer:start', (sec?: number) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    const d = Math.max(1, Math.round(Number(sec ?? s.timeLeftOverride ?? s.timerDurationSec)));
    s.timerDurationSec = d;
    s.timerEndsAt = Date.now() + d * 1000;
    s.isTimerRunning = true;
    s.timeLeftOverride = null;
    touch(s);
  });

  socket.on('timer:pause', () => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    if (!s.isTimerRunning) return;
    s.timeLeftOverride = Math.max(0, Math.round(remainingMs(s) / 1000));
    s.isTimerRunning = false;
    s.timerEndsAt = null;
    pushLog(s, `Timer dijeda (${s.timeLeftOverride}s tersisa)`);
    touch(s);
  });

  socket.on('timer:reset', (sec?: number) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    const d = Math.max(1, Math.round(Number(sec ?? s.timerDurationSec)));
    s.timerDurationSec = d;
    s.isTimerRunning = false;
    s.timerEndsAt = null;
    s.timeLeftOverride = d;
    touch(s);
  });

  socket.on('timer:adjust', (deltaSec: number) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    const cur = Math.round(remainingMs(s) / 1000);
    const next = Math.max(0, cur + Math.round(deltaSec));
    if (s.isTimerRunning && s.timerEndsAt) s.timerEndsAt = Date.now() + next * 1000;
    else s.timeLeftOverride = next;
    touch(s);
  });

  // ---------------- Pengaturan & util lain ----------------
  socket.on('settings:update', (patch: Partial<GameState['settings']>) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    const allowed: (keyof GameState['settings'])[] = ['wajibSec', 'lemparSec', 'rebutanSec', 'bonusSec', 'penaltyLempar', 'speakCountdown', 'ttsVoice'];
    for (const k of allowed) {
      if (k in patch) (s.settings as any)[k] = (patch as any)[k];
    }
    touch(s);
  });

  socket.on('spin:result', (label: string) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    s.spinWheelResult = String(label ?? '').slice(0, 60);
    pushLog(s, `Roda putar: ${s.spinWheelResult}`);
    touch(s);
  });

  socket.on('bet:set', (groupId: string, bet: number) => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    if (!s.groups.some((g) => g.id === groupId)) return;
    s.groupBets[groupId] = Math.max(0, Math.round(Number(bet) || 0));
    touch(s);
  });

  socket.on('game:reset', () => {
    if (!joinedRoom) return;
    const fresh = makeInitialState(joinedRoom);
    fresh.settings = getRoom(joinedRoom).settings;
    rooms.set(joinedRoom, fresh);
    pushLog(fresh, 'PERMAINAN DIRESET TOTAL', 'system');
    touch(fresh);
  });

  socket.on('disconnect', () => {
    if (!joinedRoom) return;
    const s = getRoom(joinedRoom);
    pushLog(s, 'Salah satu device terputus', 'system');
    broadcast(joinedRoom);
  });
});

function touch(s: GameState) {
  s.updatedAt = Date.now();
  saveSnapshot(s);
  broadcast(s.roomId);
}

function stopTimer(s: GameState, logMsg: string | null) {
  if (s.isTimerRunning) {
    s.timeLeftOverride = Math.max(0, Math.round(remainingMs(s) / 1000));
  }
  s.isTimerRunning = false;
  s.timerEndsAt = null;
  if (logMsg) pushLog(s, logMsg);
}

function publicState(s: GameState): GameState {
  // Kirim utuh; image base64 bisa besar tapi utk LAN tidak masalah.
  return s;
}

function broadcast(roomId: string) {
  const s = rooms.get(roomId);
  if (s) io.to(roomId).emit('gameState', s);
}

// Watchdog: saat timer habis, kunci bel & kabarkan semua device (server-side,
// jadi stage tetap berbunyi walau laptop admin sedang lag).
setInterval(() => {
  for (const s of rooms.values()) {
    if (s.isTimerRunning && s.timerEndsAt && Date.now() >= s.timerEndsAt) {
      s.isTimerRunning = false;
      s.timerEndsAt = null;
      s.timeLeftOverride = 0;
      s.buzzerEnabled = false;
      pushLog(s, 'WAKTU HABIS', 'system');
      io.to(s.roomId).emit('timer-expired', { questionId: s.activeQuestion?.id ?? null });
      touch(s);
    }
  }
}, 250);

server.listen(PORT, '0.0.0.0', () => {
  const nets = os.networkInterfaces();
  const ips = Object.values(nets).flat().filter((n) => n && n.family === 'IPv4' && !n.internal).map((n) => n!.address);
  console.log('============================================================');
  console.log('  CERDAS CERMAT SANTRI — server siap (mode offline/LAN)');
  console.log(`  Laptop Admin : http://localhost:${PORT}/admin/lomba`);
  console.log(`  Layar Proyektor: http://localhost:${PORT}/stage/lomba`);
  if (ips.length) console.log(`  Dari device lain (HP/kedua): http://${ips[0]}:${PORT}`);
  console.log('============================================================');
});
